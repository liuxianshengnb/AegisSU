package com.aegissu.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aegissu.manager.core.RootBackend
import com.aegissu.manager.data.AppPreferences
import com.aegissu.manager.data.PolicyDbHelper
import kotlinx.coroutines.delay

class SuPromptActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uid = intent.getIntExtra("uid", -1)
        val command = intent.getStringExtra("command") ?: "/system/bin/sh"

        val pkgs = packageManager.getPackagesForUid(uid)
        val pkgName = pkgs?.firstOrNull() ?: "uid:$uid"
        val appLabel = try {
            val ai = packageManager.getApplicationInfo(pkgName, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkgName
        }

        val db = PolicyDbHelper(this)
        val prefs = AppPreferences(this).load()

        setContent {
            MaterialTheme {
                var secondsLeft by remember { mutableIntStateOf(prefs.suTimeoutSec) }

                LaunchedEffect(Unit) {
                    while (secondsLeft > 0) {
                        delay(1000)
                        secondsLeft--
                    }
                    handleDecision(db, uid, pkgName, appLabel, command, allowed = false, persist = false)
                }

                Surface(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    shape = MaterialTheme.shapes.extraLarge,
                    tonalElevation = 8.dp
                ) {
                    Column(modifier = Modifier.padding(22.dp)) {
                        Text(
                            text = "超级用户权限请求",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("应用：$appLabel ($pkgName)", style = MaterialTheme.typography.bodyMedium)
                        Text("UID：$uid", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(10.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = command,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    handleDecision(db, uid, pkgName, appLabel, command, allowed = false, persist = true)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("拒绝 (${secondsLeft}s)")
                            }
                            FilledTonalButton(
                                onClick = {
                                    handleDecision(db, uid, pkgName, appLabel, command, allowed = true, persist = false)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("仅本次")
                            }
                            Button(
                                onClick = {
                                    handleDecision(db, uid, pkgName, appLabel, command, allowed = true, persist = true)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("永久允许")
                            }
                        }
                    }
                }
            }
        }
    }

    private fun handleDecision(
        db: PolicyDbHelper,
        uid: Int,
        pkgName: String,
        appLabel: String,
        command: String,
        allowed: Boolean,
        persist: Boolean
    ) {
        if (persist) {
            db.upsertPolicy(uid, pkgName, appLabel, granted = allowed, denyList = false)
        }
        RootBackend.writePolicyForDaemon(uid, allowed)
        db.insertLog(uid, pkgName, command, allowed)
        finish()
    }
}
