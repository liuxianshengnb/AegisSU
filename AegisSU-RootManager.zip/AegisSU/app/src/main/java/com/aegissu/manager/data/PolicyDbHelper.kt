package com.aegissu.manager.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class AppPolicy(
    val uid: Int,
    val packageName: String,
    val appName: String,
    val granted: Boolean,
    val denyList: Boolean,
    val updatedAt: Long
)

data class SuLogEntry(
    val id: Long,
    val uid: Int,
    val packageName: String,
    val command: String,
    val allowed: Boolean,
    val timestamp: Long
)

class PolicyDbHelper(context: Context) :
    SQLiteOpenHelper(context, "aegissu_policy.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE policies (
                uid INTEGER PRIMARY KEY,
                package_name TEXT NOT NULL,
                app_name TEXT NOT NULL,
                granted INTEGER NOT NULL DEFAULT 0,
                denylist INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE su_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uid INTEGER NOT NULL,
                package_name TEXT NOT NULL,
                command TEXT NOT NULL,
                allowed INTEGER NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS policies")
        db.execSQL("DROP TABLE IF EXISTS su_logs")
        onCreate(db)
    }

    fun upsertPolicy(uid: Int, packageName: String, appName: String, granted: Boolean, denyList: Boolean) {
        val values = ContentValues().apply {
            put("uid", uid)
            put("package_name", packageName)
            put("app_name", appName)
            put("granted", if (granted) 1 else 0)
            put("denylist", if (denyList) 1 else 0)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("policies", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getAllPolicies(): Map<Int, AppPolicy> {
        val map = mutableMapOf<Int, AppPolicy>()
        readableDatabase.rawQuery("SELECT * FROM policies", null).use { cursor ->
            while (cursor.moveToNext()) {
                val policy = AppPolicy(
                    uid = cursor.getInt(cursor.getColumnIndexOrThrow("uid")),
                    packageName = cursor.getString(cursor.getColumnIndexOrThrow("package_name")),
                    appName = cursor.getString(cursor.getColumnIndexOrThrow("app_name")),
                    granted = cursor.getInt(cursor.getColumnIndexOrThrow("granted")) == 1,
                    denyList = cursor.getInt(cursor.getColumnIndexOrThrow("denylist")) == 1,
                    updatedAt = cursor.getLong(cursor.getColumnIndexOrThrow("updated_at"))
                )
                map[policy.uid] = policy
            }
        }
        return map
    }

    fun insertLog(uid: Int, packageName: String, command: String, allowed: Boolean) {
        val values = ContentValues().apply {
            put("uid", uid)
            put("package_name", packageName)
            put("command", command)
            put("allowed", if (allowed) 1 else 0)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insert("su_logs", null, values)
    }

    fun getLogs(limit: Int = 100): List<SuLogEntry> {
        val list = mutableListOf<SuLogEntry>()
        readableDatabase.rawQuery(
            "SELECT * FROM su_logs ORDER BY timestamp DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(
                    SuLogEntry(
                        id = cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        uid = cursor.getInt(cursor.getColumnIndexOrThrow("uid")),
                        packageName = cursor.getString(cursor.getColumnIndexOrThrow("package_name")),
                        command = cursor.getString(cursor.getColumnIndexOrThrow("command")),
                        allowed = cursor.getInt(cursor.getColumnIndexOrThrow("allowed")) == 1,
                        timestamp = cursor.getLong(cursor.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        return list
    }

    fun clearLogs() {
        writableDatabase.delete("su_logs", null, null)
    }
}
