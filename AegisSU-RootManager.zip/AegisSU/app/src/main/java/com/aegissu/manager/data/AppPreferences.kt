package com.aegissu.manager.data

import android.content.Context
import android.content.SharedPreferences

data class UiSettings(
    val themeMode: Int,          // 0 = System, 1 = Light, 2 = Dark
    val accentIndex: Int,        // 0 = KSU Blue, 1 = Emerald, 2 = Crimson, 3 = Amber
    val bgImagePath: String?,
    val bgDimAlpha: Float,
    val cardOpacity: Float,
    val suTimeoutSec: Int
)

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("aegissu_prefs", Context.MODE_PRIVATE)

    fun load(): UiSettings = UiSettings(
        themeMode = prefs.getInt("theme_mode", 0),
        accentIndex = prefs.getInt("accent_index", 0),
        bgImagePath = prefs.getString("bg_image_path", null),
        bgDimAlpha = prefs.getFloat("bg_dim_alpha", 0.35f),
        cardOpacity = prefs.getFloat("card_opacity", 0.92f),
        suTimeoutSec = prefs.getInt("su_timeout_sec", 15)
    )

    fun save(settings: UiSettings) {
        prefs.edit()
            .putInt("theme_mode", settings.themeMode)
            .putInt("accent_index", settings.accentIndex)
            .putString("bg_image_path", settings.bgImagePath)
            .putFloat("bg_dim_alpha", settings.bgDimAlpha)
            .putFloat("card_opacity", settings.cardOpacity)
            .putInt("su_timeout_sec", settings.suTimeoutSec)
            .apply()
    }
}
