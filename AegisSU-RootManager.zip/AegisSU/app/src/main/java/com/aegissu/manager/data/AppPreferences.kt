package com.aegissu.manager.data

import android.content.Context
import android.content.SharedPreferences

data class UiSettings(
    val themeMode: Int,          // 0 = 跟随系统, 1 = 浅色, 2 = 深色
    val useMonet: Boolean,       // Android 12+ Monet 动态取色
    val enableBlur: Boolean,     // 顶栏/底栏实时模糊
    val floatingBar: Boolean,    // Apple 风格悬浮底栏
    val liquidGlass: Boolean,    // Apple 风格液态玻璃折射与水滴弹性
    val showNavBadges: Boolean,  // 导航栏角标
    val uiScale: Float,          // 全局界面缩放 (0.80f .. 1.15f)
    val bgImagePath: String?,    // 自定义背景图路径
    val bgDimAlpha: Float,       // 背景遮罩浓度
    val suTimeoutSec: Int
)

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("aegissu_prefs_v2", Context.MODE_PRIVATE)

    fun load(): UiSettings = UiSettings(
        themeMode = prefs.getInt("theme_mode", 0),
        useMonet = prefs.getBoolean("use_monet", false),
        enableBlur = prefs.getBoolean("enable_blur", true),
        floatingBar = prefs.getBoolean("floating_bar", true),
        liquidGlass = prefs.getBoolean("liquid_glass", true),
        showNavBadges = prefs.getBoolean("show_nav_badges", true),
        uiScale = prefs.getFloat("ui_scale", 1.0f),
        bgImagePath = prefs.getString("bg_image_path", null),
        bgDimAlpha = prefs.getFloat("bg_dim_alpha", 0.30f),
        suTimeoutSec = prefs.getInt("su_timeout_sec", 15)
    )

    fun save(settings: UiSettings) {
        prefs.edit()
            .putInt("theme_mode", settings.themeMode)
            .putBoolean("use_monet", settings.useMonet)
            .putBoolean("enable_blur", settings.enableBlur)
            .putBoolean("floating_bar", settings.floatingBar)
            .putBoolean("liquid_glass", settings.liquidGlass)
            .putBoolean("show_nav_badges", settings.showNavBadges)
            .putFloat("ui_scale", settings.uiScale)
            .putString("bg_image_path", settings.bgImagePath)
            .putFloat("bg_dim_alpha", settings.bgDimAlpha)
            .putInt("su_timeout_sec", settings.suTimeoutSec)
            .apply()
    }
}
