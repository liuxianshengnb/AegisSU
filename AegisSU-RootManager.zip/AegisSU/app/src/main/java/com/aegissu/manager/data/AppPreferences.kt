package com.aegissu.manager.data

import android.content.Context
import android.content.SharedPreferences

data class UiSettings(
    val themeMode: Int,          // 0 = System, 1 = Light, 2 = Dark
    val accentIndex: Int,        // 0 = Indigo, 1 = Emerald, 2 = Crimson, 3 = Amber
    val bgImagePath: String?,    // Local copied image path
    val bgDimAlpha: Float,       // 0.1f .. 0.85f
    val glassBlurAlpha: Float,   // 0.55f .. 0.95f
    val suTimeoutSec: Int,       // 10, 15, 30
    val suNotification: Boolean
)

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("aegissu_prefs", Context.MODE_PRIVATE)

    fun load(): UiSettings = UiSettings(
        themeMode = prefs.getInt("theme_mode", 0),
        accentIndex = prefs.getInt("accent_index", 0),
        bgImagePath = prefs.getString("bg_image_path", null),
        bgDimAlpha = prefs.getFloat("bg_dim_alpha", 0.45f),
        glassBlurAlpha = prefs.getFloat("glass_blur_alpha", 0.78f),
        suTimeoutSec = prefs.getInt("su_timeout_sec", 15),
        suNotification = prefs.getBoolean("su_notification", true)
    )

    fun save(settings: UiSettings) {
        prefs.edit()
            .putInt("theme_mode", settings.themeMode)
            .putInt("accent_index", settings.accentIndex)
            .putString("bg_image_path", settings.bgImagePath)
            .putFloat("bg_dim_alpha", settings.bgDimAlpha)
            .putFloat("glass_blur_alpha", settings.glassBlurAlpha)
            .putInt("su_timeout_sec", settings.suTimeoutSec)
            .putBoolean("su_notification", settings.suNotification)
            .apply()
    }
}
