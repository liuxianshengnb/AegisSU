package com.aegissu.manager.core

import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

data class BootHeaderInfo(
    val isValid: Boolean,
    val headerVersion: Int,
    val kernelSize: Int,
    val ramdiskSize: Int,
    val pageSize: Int,
    val osVersionRaw: Int,
    val cmdline: String,
    val sha256: String,
    val fileSize: Long
)

data class PatchOutcome(
    val success: Boolean,
    val outputPath: String,
    val logs: List<String>
)

object BootImagePatcher {

    private const val BOOT_MAGIC = "ANDROID!"

    fun parseBootImage(file: File): BootHeaderInfo {
        if (!file.exists() || file.length() < 4096) {
            return BootHeaderInfo(false, 0, 0, 0, 4096, 0, "", "", file.length())
        }

        val headerBytes = ByteArray(2048)
        RandomAccessFile(file, "r").use { raf ->
            raf.readFully(headerBytes)
        }

        val magic = String(headerBytes, 0, 8, Charsets.US_ASCII)
        if (magic != BOOT_MAGIC) {
            return BootHeaderInfo(false, 0, 0, 0, 4096, 0, "", sha256File(file), file.length())
        }

        val buf = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(8)
        val firstField = buf.int
        val secondField = buf.int
        val thirdField = buf.int
        val fourthField = buf.int
        val fifthField = buf.int
        val sixthField = buf.int
        val seventhField = buf.int
        val eighthField = buf.int
        val ninthField = buf.int

        // Boot Header v3/v4 stores header_version at offset 40 (ninthField after magic)
        val isV3Plus = ninthField in 3..4 && (fifthField in 3..4 || thirdField > 0)
        return if (isV3Plus) {
            val kernelSz = firstField
            val ramdiskSz = secondField
            val osVer = thirdField
            val hdrVer = fifthField
            val cmdBytes = headerBytes.copyOfRange(44, 44 + 512)
            val cmd = cmdBytes.takeWhile { it != 0.toByte() }.toByteArray().toString(Charsets.UTF_8)
            BootHeaderInfo(
                isValid = true,
                headerVersion = hdrVer,
                kernelSize = kernelSz,
                ramdiskSize = ramdiskSz,
                pageSize = 4096,
                osVersionRaw = osVer,
                cmdline = cmd,
                sha256 = sha256File(file),
                fileSize = file.length()
            )
        } else {
            val kernelSz = firstField
            val ramdiskSz = thirdField
            val pageSz = if (eighthField in listOf(2048, 4096, 8192, 16384)) eighthField else 4096
            val hdrVer = ninthField.coerceIn(0, 2)
            val osVer = seventhField
            val cmdBytes = headerBytes.copyOfRange(64, 64 + 512)
            val cmd = cmdBytes.takeWhile { it != 0.toByte() }.toByteArray().toString(Charsets.UTF_8)
            BootHeaderInfo(
                isValid = true,
                headerVersion = hdrVer,
                kernelSize = kernelSz,
                ramdiskSize = ramdiskSz,
                pageSize = pageSz,
                osVersionRaw = osVer,
                cmdline = cmd,
                sha256 = sha256File(file),
                fileSize = file.length()
            )
        }
    }

    fun patchBootImage(
        context: Context,
        inputBoot: File,
        header: BootHeaderInfo
    ): PatchOutcome {
        val logs = mutableListOf<String>()
        logs.add("[*] 读取镜像: ${inputBoot.name} (${header.fileSize / 1024} KB)")
        if (!header.isValid) {
            logs.add("[!] 错误: 未检测到 ANDROID! 魔数头，请选择有效的 boot.img 或 init_boot.img")
            return PatchOutcome(false, "", logs)
        }

        logs.add("[*] 解析头部成功: Header v${header.headerVersion}, PageSize=${header.pageSize}")
        logs.add("[*] Kernel 大小: ${header.kernelSize} bytes, Ramdisk 大小: ${header.ramdiskSize} bytes")
        logs.add("[*] 原始 SHA256: ${header.sha256.take(24)}...")

        val workDir = File(context.cacheDir, "boot_patch").apply {
            deleteRecursively()
            mkdirs()
        }
        val stagedBoot = File(workDir, "boot.img")
        inputBoot.copyTo(stagedBoot, overwrite = true)

        val outDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        outDir.mkdirs()
        val outName = "aegissu_patched_${System.currentTimeMillis() / 1000}.img"
        val finalOutFile = File(outDir, outName)

        // 1. Check if ksud is available for official KernelSU LKM patching
        val ksuCheck = RootBackend.execRoot("ls /data/adb/ksud 2>/dev/null")
        if (ksuCheck.exitCode == 0 && ksuCheck.stdout.isNotBlank()) {
            logs.add("[*] 检测到 KernelSU 工具链 (/data/adb/ksud)，尝试调用 ksud boot-patch...")
            val res = RootBackend.execRoot(
                "cd ${workDir.absolutePath} && /data/adb/ksud boot-patch -b ${stagedBoot.absolutePath}"
            )
            val patchedCandidate = workDir.listFiles()?.firstOrNull {
                it.name.startsWith("kernelsu_patched") && it.name.endsWith(".img")
            }
            if (res.exitCode == 0 && patchedCandidate != null) {
                patchedCandidate.copyTo(finalOutFile, overwrite = true)
                logs.add("[+] ksud 修补完成！已输出至: ${finalOutFile.absolutePath}")
                return PatchOutcome(true, finalOutFile.absolutePath, logs)
            } else {
                logs.add("[!] ksud 直接修补未返回镜像，切换至内置 AegisSU Ramdisk 注入引擎...")
            }
        }

        // 2. Check if magiskboot is available on device
        val mbPaths = listOf(
            "/data/adb/magisk/magiskboot",
            "/data/adb/ksu/bin/magiskboot",
            "${context.applicationInfo.nativeLibraryDir}/libmagiskboot.so"
        )
        val magiskBoot = mbPaths.firstOrNull { File(it).exists() }
        val nativeSu = File(context.applicationInfo.nativeLibraryDir, "libaegissu.so")

        if (magiskBoot != null && nativeSu.exists()) {
            logs.add("[*] 发现底层解包工具: $magiskBoot")
            val unpackRes = RootBackend.execRoot("cd ${workDir.absolutePath} && $magiskBoot unpack ${stagedBoot.absolutePath}")
            logs.add("[*] magiskboot unpack 返回码: ${unpackRes.exitCode}")
            val cpioFile = File(workDir, "ramdisk.cpio")
            if (cpioFile.exists()) {
                val injectRes = RootBackend.execRoot(
                    "cd ${workDir.absolutePath} && " +
                        "$magiskBoot cpio ramdisk.cpio " +
                        ""mkdir 0750 overlay.d" " +
                        ""mkdir 0750 overlay.d/sbin" " +
                        ""add 04755 overlay.d/sbin/su ${nativeSu.absolutePath}""
                )
                logs.add("[*] 注入原生 libaegissu.so 至 ramdisk.cpio (overlay.d/sbin/su): code=${injectRes.exitCode}")
                val repackRes = RootBackend.execRoot("cd ${workDir.absolutePath} && $magiskBoot repack ${stagedBoot.absolutePath}")
                val newBoot = File(workDir, "new-boot.img")
                if (repackRes.exitCode == 0 && newBoot.exists()) {
                    newBoot.copyTo(finalOutFile, overwrite = true)
                    logs.add("[+] magiskboot 重打包完成！输出路径: ${finalOutFile.absolutePath}")
                    return PatchOutcome(true, finalOutFile.absolutePath, logs)
                }
            }
        }

        // 3. Built-in pure Kotlin/C binary ramdisk overlay patcher (works on unrooted phones!)
        logs.add("[*] 启动内置免 Root 镜像注入器 (AegisSU Native Ramdisk Appender)...")
        if (!nativeSu.exists()) {
            logs.add("[!] 未找到内置二进制 ${nativeSu.absolutePath}")
            return PatchOutcome(false, "", logs)
        }
        logs.add("[*] 提取 APK 内置原生守护程序: ${nativeSu.name} (${nativeSu.length() / 1024} KB)")

        return try {
            val cpioOverlay = buildNewcCpioArchive("overlay.d/sbin/su", nativeSu.readBytes(), mode = 0b100_111_101_101) // 0104755
            logs.add("[*] 生成 newc CPIO 提权归档段 (${cpioOverlay.size} bytes)")

            stagedBoot.copyTo(finalOutFile, overwrite = true)
            RandomAccessFile(finalOutFile, "rw").use { raf ->
                // Append the cpio archive aligned to pageSize and update ramdisk size & trailer
                val alignedPos = alignUp(raf.length(), header.pageSize.toLong())
                raf.seek(alignedPos)
                raf.write(cpioOverlay)

                // Write AegisSU patch signature footer
                val footer = "AEGISSU_PATCHED_V2:${header.sha256.take(16)}".toByteArray(Charsets.UTF_8)
                raf.write(footer)

                // Update ramdisk_size in boot header so bootloader loads appended cpio segment
                val newRamdiskSize = header.ramdiskSize + cpioOverlay.size
                val sizeBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(newRamdiskSize).array()
                val ramdiskSizeOffset = if (header.headerVersion >= 3) 12L else 16L
                raf.seek(ramdiskSizeOffset)
                raf.write(sizeBuf)
            }

            val newSha = sha256File(finalOutFile)
            logs.add("[*] 已更新 Boot Header ramdisk_size -> ${header.ramdiskSize + cpioOverlay.size} bytes")
            logs.add("[*] 修补后 SHA256: ${newSha.take(24)}...")
            logs.add("[+] 修补成功！文件已保存至: ${finalOutFile.absolutePath}")
            logs.add("[i] 刷入命令: fastboot flash boot ${finalOutFile.name}")
            PatchOutcome(true, finalOutFile.absolutePath, logs)
        } catch (e: Exception) {
            logs.add("[!] 修补异常: ${e.message}")
            PatchOutcome(false, "", logs)
        }
    }

    private fun alignUp(value: Long, align: Long): Long {
        val rem = value % align
        return if (rem == 0L) value else value + (align - rem)
    }

    private fun buildNewcCpioArchive(entryName: String, fileData: ByteArray, mode: Int): ByteArray {
        val nameBytes = (entryName + "\u0000").toByteArray(Charsets.US_ASCII)
        val headerStr = String.format(
            "070701%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X",
            1,                  // ino
            mode,               // mode (regular file + SUID 04755)
            0,                  // uid (root)
            0,                  // gid (root)
            1,                  // nlink
            0,                  // mtime
            fileData.size,      // filesize
            0, 0, 0, 0,
            nameBytes.size,     // namesize
            0                   // check
        )
        val headerBytes = headerStr.toByteArray(Charsets.US_ASCII)
        val headPad = (4 - ((headerBytes.size + nameBytes.size) % 4)) % 4
        val dataPad = (4 - (fileData.size % 4)) % 4

        val trailerName = ("TRAILER!!!" + "\u0000").toByteArray(Charsets.US_ASCII)
        val trailerHdr = String.format(
            "070701%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X",
            0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, trailerName.size, 0
        ).toByteArray(Charsets.US_ASCII)
        val trailerPad = (4 - ((trailerHdr.size + trailerName.size) % 4)) % 4

        val totalSize = headerBytes.size + nameBytes.size + headPad +
            fileData.size + dataPad +
            trailerHdr.size + trailerName.size + trailerPad

        val out = ByteBuffer.allocate(totalSize)
        out.put(headerBytes)
        out.put(nameBytes)
        repeat(headPad) { out.put(0) }
        out.put(fileData)
        repeat(dataPad) { out.put(0) }
        out.put(trailerHdr)
        out.put(trailerName)
        repeat(trailerPad) { out.put(0) }
        return out.array()
    }

    private fun sha256File(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(8192)
            var n: Int
            while (input.read(buf).also { n = it } > 0) {
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
