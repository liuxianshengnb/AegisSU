package com.aegissu.manager.core

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

data class BootHeaderInfo(
    val isValid: Boolean,
    val headerVersion: Int,
    val kernelSize: Int,
    val ramdiskSize: Int,
    val pageSize: Int,
    val cmdline: String,
    val sha256: String,
    val fileSize: Long
)

data class PatchOutcome(
    val success: Boolean,
    val outputPath: String,
    val logs: List<String>
)

object BootImagePatcher {

    private const val BOOT_MAGIC = "ANDROID!"

    fun parseBootImage(file: File): BootHeaderInfo {
        if (!file.exists() || file.length() < 4096) {
            return BootHeaderInfo(false, 0, 0, 0, 4096, "", "", file.length())
        }

        val headerBytes = ByteArray(2048)
        RandomAccessFile(file, "r").use { raf ->
            raf.readFully(headerBytes)
        }

        val magic = String(headerBytes, 0, 8, Charsets.US_ASCII)
        if (magic != BOOT_MAGIC) {
            return BootHeaderInfo(false, 0, 0, 0, 4096, "", sha256File(file), file.length())
        }

        val buf = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(8)
        val firstField = buf.int
        val secondField = buf.int
        val thirdField = buf.int
        val fourthField = buf.int
        val fifthField = buf.int
        buf.int
        buf.int
        val eighthField = buf.int
        val ninthField = buf.int

        val isV3Plus = fifthField in 3..4 || (ninthField in 3..4 && fourthField == 0)
        return if (isV3Plus) {
            val hdrVer = if (fifthField in 3..4) fifthField else ninthField
            val cmdBytes = headerBytes.copyOfRange(44, 44 + 512)
            val cmd = cmdBytes.takeWhile { it != 0.toByte() }.toByteArray().toString(Charsets.UTF_8)
            BootHeaderInfo(
                isValid = true,
                headerVersion = hdrVer,
                kernelSize = firstField,
                ramdiskSize = secondField,
                pageSize = 4096,
                cmdline = cmd,
                sha256 = sha256File(file),
                fileSize = file.length()
            )
        } else {
            val pageSz = if (eighthField in listOf(2048, 4096, 8192, 16384)) eighthField else 4096
            val hdrVer = ninthField.coerceIn(0, 2)
            val cmdBytes = headerBytes.copyOfRange(64, 64 + 512)
            val cmd = cmdBytes.takeWhile { it != 0.toByte() }.toByteArray().toString(Charsets.UTF_8)
            BootHeaderInfo(
                isValid = true,
                headerVersion = hdrVer,
                kernelSize = firstField,
                ramdiskSize = thirdField,
                pageSize = pageSz,
                cmdline = cmd,
                sha256 = sha256File(file),
                fileSize = file.length()
            )
        }
    }

    fun patchBootImage(
        context: Context,
        inputBoot: File,
        header: BootHeaderInfo
    ): PatchOutcome {
        val logs = mutableListOf<String>()
        logs.add("[*] 读取镜像: ${inputBoot.name} (${header.fileSize / 1024} KB)")
        if (!header.isValid) {
            logs.add("[!] 错误: 未检测到 ANDROID! 魔数头")
            return PatchOutcome(false, "", logs)
        }

        val workDir = File(context.cacheDir, "boot_patch").apply {
            deleteRecursively()
            mkdirs()
        }
        val stagedBoot = File(workDir, "boot.img")
        inputBoot.copyTo(stagedBoot, overwrite = true)

        val outDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        outDir.mkdirs()
        val outName = "aegissu_patched_${System.currentTimeMillis() / 1000}.img"
        val finalOutFile = File(outDir, outName)

        // 1. Official KernelSU ksud boot-patch if available
        val ksuCheck = RootBackend.execRoot("ls /data/adb/ksud 2>/dev/null")
        if (ksuCheck.exitCode == 0 && ksuCheck.stdout.isNotBlank()) {
            logs.add("[*] 检测到 /data/adb/ksud，调用官方 boot-patch...")
            val res = RootBackend.execRoot("cd ${workDir.absolutePath} && /data/adb/ksud boot-patch -b ${stagedBoot.absolutePath}")
            val patchedCandidate = workDir.listFiles()?.firstOrNull {
                it.name.startsWith("kernelsu_patched") && it.name.endsWith(".img")
            }
            if (res.exitCode == 0 && patchedCandidate != null) {
                patchedCandidate.copyTo(finalOutFile, overwrite = true)
                logs.add("[+] ksud 修补成功: ${finalOutFile.absolutePath}")
                return PatchOutcome(true, finalOutFile.absolutePath, logs)
            }
        }

        // 2. Magiskboot cpio injection if available
        val mbPaths = listOf(
            "/data/adb/magisk/magiskboot",
            "/data/adb/ksu/bin/magiskboot",
            "${context.applicationInfo.nativeLibraryDir}/libmagiskboot.so"
        )
        val magiskBoot = mbPaths.firstOrNull { File(it).exists() }
        val nativeSu = File(context.applicationInfo.nativeLibraryDir, "libaegissu.so")

        if (magiskBoot != null && nativeSu.exists()) {
            logs.add("[*] 使用底层解包工具: $magiskBoot")
            RootBackend.execRoot("cd ${workDir.absolutePath} && $magiskBoot unpack ${stagedBoot.absolutePath}")
            val cpioFile = File(workDir, "ramdisk.cpio")
            if (cpioFile.exists()) {
                val suPath = nativeSu.absolutePath
                val cpioCmd = "cd ${workDir.absolutePath} && $magiskBoot cpio ramdisk.cpio " +
                    "'mkdir 0750 overlay.d' " +
                    "'mkdir 0750 overlay.d/sbin' " +
                    "'add 04755 overlay.d/sbin/su $suPath'"
                val injectRes = RootBackend.execRoot(cpioCmd)
                logs.add("[*] CPIO 注入返回码: ${injectRes.exitCode}")
                val repackRes = RootBackend.execRoot("cd ${workDir.absolutePath} && $magiskBoot repack ${stagedBoot.absolutePath}")
                val newBoot = File(workDir, "new-boot.img")
                if (repackRes.exitCode == 0 && newBoot.exists()) {
                    newBoot.copyTo(finalOutFile, overwrite = true)
                    logs.add("[+] 重打包成功: ${finalOutFile.absolutePath}")
                    return PatchOutcome(true, finalOutFile.absolutePath, logs)
                }
            }
        }

        // 3. Built-in native CPIO ramdisk appender (works without prior root)
        logs.add("[*] 启动内置原生 Ramdisk 注入引擎...")
        if (!nativeSu.exists()) {
            logs.add("[!] 找不到内置 libaegissu.so")
            return PatchOutcome(false, "", logs)
        }

        return try {
            val cpioOverlay = buildNewcCpioArchive("overlay.d/sbin/su", nativeSu.readBytes(), 35309) // 0104755 octal
            stagedBoot.copyTo(finalOutFile, overwrite = true)
            RandomAccessFile(finalOutFile, "rw").use { raf ->
                val alignedPos = alignUp(raf.length(), header.pageSize.toLong())
                raf.seek(alignedPos)
                raf.write(cpioOverlay)
                val newRamdiskSize = header.ramdiskSize + cpioOverlay.size
                val sizeBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(newRamdiskSize).array()
                val ramdiskSizeOffset = if (header.headerVersion >= 3) 12L else 16L
                raf.seek(ramdiskSizeOffset)
                raf.write(sizeBuf)
            }
            logs.add("[*] 注入 newc CPIO (${cpioOverlay.size} bytes), 更新 ramdisk_size")
            logs.add("[+] 修补完成: ${finalOutFile.absolutePath}")
            logs.add("[i] 使用 fastboot flash boot ${finalOutFile.name} 刷入即可")
            PatchOutcome(true, finalOutFile.absolutePath, logs)
        } catch (e: Exception) {
            logs.add("[!] 修补失败: ${e.message}")
            PatchOutcome(false, "", logs)
        }
    }

    private fun alignUp(value: Long, align: Long): Long {
        val rem = value % align
        return if (rem == 0L) value else value + (align - rem)
    }

    private fun buildNewcCpioArchive(entryName: String, fileData: ByteArray, mode: Int): ByteArray {
        val nameBytes = (entryName + "\u0000").toByteArray(Charsets.US_ASCII)
        val headerStr = String.format(
            "070701%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X",
            1, mode, 0, 0, 1, 0, fileData.size, 0, 0, 0, 0, nameBytes.size, 0
        )
        val headerBytes = headerStr.toByteArray(Charsets.US_ASCII)
        val headPad = (4 - ((headerBytes.size + nameBytes.size) % 4)) % 4
        val dataPad = (4 - (fileData.size % 4)) % 4

        val trailerName = ("TRAILER!!!" + "\u0000").toByteArray(Charsets.US_ASCII)
        val trailerHdr = String.format(
            "070701%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X%08X",
            0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, trailerName.size, 0
        ).toByteArray(Charsets.US_ASCII)
        val trailerPad = (4 - ((trailerHdr.size + trailerName.size) % 4)) % 4

        val totalSize = headerBytes.size + nameBytes.size + headPad +
            fileData.size + dataPad + trailerHdr.size + trailerName.size + trailerPad

        val out = ByteBuffer.allocate(totalSize)
        out.put(headerBytes)
        out.put(nameBytes)
        repeat(headPad) { out.put(0) }
        out.put(fileData)
        repeat(dataPad) { out.put(0) }
        out.put(trailerHdr)
        out.put(trailerName)
        repeat(trailerPad) { out.put(0) }
        return out.array()
    }

    private fun sha256File(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(8192)
            var n: Int
            while (input.read(buf).also { n = it } > 0) {
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
