package com.aegissu.manager.core

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

enum class RootFramework(val displayName: String) {
    KERNEL_SU("KernelSU"),
    MAGISK("Magisk"),
    AEGIS_DAEMON("AegisSU Daemon"),
    NONE("未获取 Root")
}

data class SystemStatus(
    val framework: RootFramework,
    val frameworkVersion: String,
    val kernelVersion: String,
    val selinuxMode: String,
    val isRooted: Boolean
)

data class RootModule(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val enabled: Boolean,
    val pendingRemove: Boolean
)

data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String
)

object RootBackend {

    private val suCandidates = listOf(
        "/data/adb/aegissu/su",
        "/data/adb/ksu/bin/su",
        "/sbin/su",
        "/system/bin/su",
        "/system/xbin/su"
    )

    fun execRoot(command: String): ShellResult {
        val suBin = suCandidates.firstOrNull { File(it).exists() } ?: "su"
        return try {
            val process = ProcessBuilder(suBin, "-c", command).start()
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
            val code = process.waitFor()
            ShellResult(code, stdout, stderr)
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "exec failed")
        }
    }

    fun execLocal(command: String): ShellResult {
        return try {
            val process = ProcessBuilder("sh", "-c", command).start()
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
            val code = process.waitFor()
            ShellResult(code, stdout, stderr)
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "exec failed")
        }
    }

    fun detectSystemStatus(): SystemStatus {
        val kernel = execLocal("uname -r").stdout.ifEmpty { "Unknown" }
        val selinux = execRoot("getenforce").stdout.ifEmpty {
            execLocal("getenforce").stdout.ifEmpty { "Unknown" }
        }

        val ksuVer = execRoot("/data/adb/ksud -V").stdout
        if (ksuVer.isNotEmpty()) {
            return SystemStatus(RootFramework.KERNEL_SU, ksuVer, kernel, selinux, true)
        }

        val magiskVer = execRoot("magisk -v").stdout
        if (magiskVer.isNotEmpty()) {
            return SystemStatus(RootFramework.MAGISK, magiskVer, kernel, selinux, true)
        }

        val idCheck = execRoot("id -u")
        if (idCheck.exitCode == 0 && idCheck.stdout == "0") {
            return SystemStatus(RootFramework.AEGIS_DAEMON, "1.0.0", kernel, selinux, true)
        }

        return SystemStatus(RootFramework.NONE, "-", kernel, selinux, false)
    }

    fun writePolicyForDaemon(uid: Int, granted: Boolean) {
        val flag = if (granted) "1" else "0"
        execRoot("mkdir -p /data/adb/aegissu/policy && echo '$flag' > /data/adb/aegissu/policy/$uid && chmod 600 /data/adb/aegissu/policy/$uid")
    }

    fun setDenyList(framework: RootFramework, packageName: String, enable: Boolean): Boolean {
        val cmd = when (framework) {
            RootFramework.MAGISK -> {
                if (enable) "magisk --denylist add $packageName"
                else "magisk --denylist rm $packageName"
            }
            RootFramework.KERNEL_SU -> {
                if (enable) "/data/adb/ksud profile set-umount $packageName 1"
                else "/data/adb/ksud profile set-umount $packageName 0"
            }
            else -> return false
        }
        return execRoot(cmd).exitCode == 0
    }

    fun listModules(): List<RootModule> {
        val res = execRoot("ls -1 /data/adb/modules 2>/dev/null")
        if (res.exitCode != 0 || res.stdout.isBlank()) return emptyList()

        return res.stdout.lines().filter { it.isNotBlank() }.mapNotNull { dir ->
            val propText = execRoot("cat /data/adb/modules/$dir/module.prop 2>/dev/null").stdout
            if (propText.isBlank()) return@mapNotNull null

            val props = mutableMapOf<String, String>()
            propText.lines().forEach { line ->
                val idx = line.indexOf('=')
                if (idx > 0) {
                    props[line.substring(0, idx).trim()] = line.substring(idx + 1).trim()
                }
            }

            val disabled = execRoot("[ -f /data/adb/modules/$dir/disable ] && echo 1 || echo 0").stdout == "1"
            val remove = execRoot("[ -f /data/adb/modules/$dir/remove ] && echo 1 || echo 0").stdout == "1"

            RootModule(
                id = props["id"] ?: dir,
                name = props["name"] ?: dir,
                version = props["version"] ?: "1.0",
                author = props["author"] ?: "Unknown",
                description = props["description"] ?: "",
                enabled = !disabled,
                pendingRemove = remove
            )
        }
    }

    fun toggleModule(moduleId: String, enable: Boolean): Boolean {
        val cmd = if (enable) {
            "rm -f /data/adb/modules/$moduleId/disable"
        } else {
            "touch /data/adb/modules/$moduleId/disable"
        }
        return execRoot(cmd).exitCode == 0
    }

    fun toggleRemoveModule(moduleId: String, markRemove: Boolean): Boolean {
        val cmd = if (markRemove) {
            "touch /data/adb/modules/$moduleId/remove"
        } else {
            "rm -f /data/adb/modules/$moduleId/remove"
        }
        return execRoot(cmd).exitCode == 0
    }

    fun installModuleZip(framework: RootFramework, zipPath: String): ShellResult {
        val cmd = when (framework) {
            RootFramework.KERNEL_SU -> "/data/adb/ksud module install "$zipPath""
            RootFramework.MAGISK -> "magisk --install-module "$zipPath""
            else -> return ShellResult(-1, "", "当前后端不支持模块安装")
        }
        return execRoot(cmd)
    }

    fun reboot(target: String = "") {
        val cmd = if (target.isBlank()) "svc power reboot" else "svc power reboot $target"
        execRoot(cmd)
    }
}
