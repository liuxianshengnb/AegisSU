package com.aegissu.manager.core

import android.os.Build
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

enum class RootFramework(val displayName: String) {
    KERNEL_SU("KernelSU"),
    MAGISK("Magisk"),
    AEGIS_DAEMON("AegisSU Native"),
    NONE("未安装")
}

data class SystemStatus(
    val framework: RootFramework,
    val frameworkVersion: String,
    val kernelVersion: String,
    val selinuxMode: String,
    val deviceModel: String,
    val androidVersion: String,
    val abi: String,
    val slotSuffix: String,
    val isRooted: Boolean
)

data class RootModule(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val enabled: Boolean,
    val pendingRemove: Boolean
)

data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String
)

object RootBackend {

    private val suCandidates = listOf(
        "/data/adb/aegissu/su",
        "/data/adb/ksu/bin/su",
        "/sbin/su",
        "/system/bin/su",
        "/system/xbin/su"
    )

    fun execRoot(command: String): ShellResult {
        val suBin = suCandidates.firstOrNull { File(it).exists() } ?: "su"
        return try {
            val process = ProcessBuilder(suBin, "-c", command).start()
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
            val code = process.waitFor()
            ShellResult(code, stdout, stderr)
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "exec failed")
        }
    }

    fun execLocal(command: String): ShellResult {
        return try {
            val process = ProcessBuilder("sh", "-c", command).start()
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
            val code = process.waitFor()
            ShellResult(code, stdout, stderr)
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "exec failed")
        }
    }

    fun detectSystemStatus(): SystemStatus {
        val sysInfo = execLocal("uname -r; echo '---'; getenforce 2>/dev/null || echo Unknown; echo '---'; getprop ro.boot.slot_suffix").stdout.split("---")
        val kernel = sysInfo.getOrNull(0)?.trim().orEmpty().ifEmpty { System.getProperty("os.version") ?: "Unknown" }
        val selinuxLocal = sysInfo.getOrNull(1)?.trim().orEmpty().ifEmpty { "Enforcing" }
        val slot = sysInfo.getOrNull(2)?.trim().orEmpty().ifEmpty { "Non-A/B" }

        val model = "${Build.MANUFACTURER} ${Build.MODEL}"
        val androidVer = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"

        // Single root probe instead of multiple ProcessBuilder calls
        val probe = execRoot("echo UID=$(id -u); echo SE=$(getenforce 2>/dev/null); echo KSU=$(/data/adb/ksud -V 2>/dev/null); echo MAG=$(magisk -v 2>/dev/null)")
        if (probe.exitCode == 0) {
            val lines = probe.stdout.lines().associate {
                val idx = it.indexOf('=')
                if (idx > 0) it.substring(0, idx) to it.substring(idx + 1).trim() else "" to ""
            }
            val selinux = lines["SE"].orEmpty().ifEmpty { selinuxLocal }
            val ksu = lines["KSU"].orEmpty()
            val mag = lines["MAG"].orEmpty()
            val uid = lines["UID"].orEmpty()

            if (ksu.isNotEmpty()) {
                return SystemStatus(RootFramework.KERNEL_SU, ksu, kernel, selinux, model, androidVer, abi, slot, true)
            }
            if (mag.isNotEmpty()) {
                return SystemStatus(RootFramework.MAGISK, mag, kernel, selinux, model, androidVer, abi, slot, true)
            }
            if (uid == "0") {
                return SystemStatus(RootFramework.AEGIS_DAEMON, "2.1.0", kernel, selinux, model, androidVer, abi, slot, true)
            }
        }

        return SystemStatus(RootFramework.NONE, "-", kernel, selinuxLocal, model, androidVer, abi, slot, false)
    }

    // Single shell invocation to fetch all modules quickly (zero lag!)
    fun listModules(): List<RootModule> {
        val script = "for d in /data/adb/modules/*; do " +
            "[ -f "\$d/module.prop" ] || continue; " +
            "echo '===MOD==='; " +
            "echo "__DIR=\${d##*/}"; " +
            "[ -f "\$d/disable" ] && echo '__DIS=1' || echo '__DIS=0'; " +
            "[ -f "\$d/remove" ] && echo '__REM=1' || echo '__REM=0'; " +
            "cat "\$d/module.prop"; " +
            "done"
        val res = execRoot(script)
        if (res.exitCode != 0 || res.stdout.isBlank()) return emptyList()

        return res.stdout.split("===MOD===").mapNotNull { block ->
            val lines = block.trim().lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) return@mapNotNull null
            val props = mutableMapOf<String, String>()
            lines.forEach { line ->
                val idx = line.indexOf('=')
                if (idx > 0) props[line.substring(0, idx).trim()] = line.substring(idx + 1).trim()
            }
            val dir = props["__DIR"] ?: return@mapNotNull null
            RootModule(
                id = props["id"] ?: dir,
                name = props["name"] ?: dir,
                version = props["version"] ?: "1.0",
                author = props["author"] ?: "Unknown",
                description = props["description"] ?: "",
                enabled = props["__DIS"] != "1",
                pendingRemove = props["__REM"] == "1"
            )
        }
    }

    fun findActiveBootBlockPath(): String? {
        val slot = execLocal("getprop ro.boot.slot_suffix").stdout.trim()
        val candidates = listOf(
            "/dev/block/by-name/init_boot$slot",
            "/dev/block/by-name/boot$slot",
            "/dev/block/bootdevice/by-name/init_boot$slot",
            "/dev/block/bootdevice/by-name/boot$slot",
            "/dev/block/by-name/boot"
        )
        val script = candidates.joinToString("; ") { "[ -e '$it' ] && echo '$it' && exit 0" }
        val res = execRoot(script)
        return if (res.exitCode == 0 && res.stdout.isNotBlank()) res.stdout.lines().first() else null
    }

    fun dumpActiveBootPartition(destFile: File): ShellResult {
        val block = findActiveBootBlockPath()
            ?: return ShellResult(-1, "", "未找到 boot 分区或当前无 Root 权限直接提取，请手动选择本地 boot.img")
        return execRoot("dd if='$block' of='${destFile.absolutePath}' bs=4096 && chmod 0644 '${destFile.absolutePath}'")
    }

    fun flashBootPartition(patchedImg: File): ShellResult {
        val block = findActiveBootBlockPath()
            ?: return ShellResult(-1, "", "未检测到可写入的 boot 分区节点")
        return execRoot("dd if='${patchedImg.absolutePath}' of='$block' bs=4096")
    }

    fun deployNativeDaemon(nativeSoPath: String): ShellResult {
        val cmd = "mkdir -p /data/adb/aegissu/policy && " +
            "cp '$nativeSoPath' /data/adb/aegissu/su && " +
            "chown 0:0 /data/adb/aegissu/su && " +
            "chmod 04755 /data/adb/aegissu/su && " +
            "/data/adb/aegissu/su --daemon &"
        return execRoot(cmd)
    }

    fun writePolicyForDaemon(uid: Int, granted: Boolean) {
        val flag = if (granted) "1" else "0"
        execRoot("mkdir -p /data/adb/aegissu/policy && echo '$flag' > /data/adb/aegissu/policy/$uid && chmod 600 /data/adb/aegissu/policy/$uid")
    }

    fun setDenyList(framework: RootFramework, packageName: String, enable: Boolean): Boolean {
        val cmd = when (framework) {
            RootFramework.MAGISK -> {
                if (enable) "magisk --denylist add $packageName"
                else "magisk --denylist rm $packageName"
            }
            RootFramework.KERNEL_SU -> {
                if (enable) "/data/adb/ksud profile set-umount $packageName 1"
                else "/data/adb/ksud profile set-umount $packageName 0"
            }
            else -> return false
        }
        return execRoot(cmd).exitCode == 0
    }

    fun toggleModule(moduleId: String, enable: Boolean): Boolean {
        val cmd = if (enable) "rm -f /data/adb/modules/$moduleId/disable"
        else "touch /data/adb/modules/$moduleId/disable"
        return execRoot(cmd).exitCode == 0
    }

    fun toggleRemoveModule(moduleId: String, markRemove: Boolean): Boolean {
        val cmd = if (markRemove) "touch /data/adb/modules/$moduleId/remove"
        else "rm -f /data/adb/modules/$moduleId/remove"
        return execRoot(cmd).exitCode == 0
    }

    fun installModuleZip(framework: RootFramework, zipPath: String): ShellResult {
        val cmd = when (framework) {
            RootFramework.KERNEL_SU -> "/data/adb/ksud module install '$zipPath'"
            RootFramework.MAGISK -> "magisk --install-module '$zipPath'"
            else -> return ShellResult(-1, "", "当前后端不支持模块安装")
        }
        return execRoot(cmd)
    }

    fun reboot(target: String = "") {
        val cmd = if (target.isBlank()) "svc power reboot" else "svc power reboot $target"
        execRoot(cmd)
    }
}
