package com.aegissu.manager

import android.content.pm.ApplicationInfo
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aegissu.manager.core.*
import com.aegissu.manager.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class InstalledAppItem(
    val uid: Int,
    val packageName: String,
    val appName: String,
    val isSystem: Boolean,
    val granted: Boolean,
    val denyList: Boolean
)

data class NavItem(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        setContent {
            AegisSuRootApp()
        }
    }
}

private val AccentPalettes = listOf(
    Color(0xFF4F46E5), // KernelSU Indigo
    Color(0xFF059669), // Emerald Green
    Color(0xFFE11D48), // Crimson Rose
    Color(0xFFD97706)  // Amber Gold
)

@Composable
fun buildThemeScheme(darkTheme: Boolean, accentIndex: Int): ColorScheme {
    val seed = AccentPalettes.getOrElse(accentIndex) { AccentPalettes[0] }
    return if (darkTheme) {
        darkColorScheme(
            primary = seed,
            onPrimary = Color.White,
            primaryContainer = seed.copy(alpha = 0.28f),
            onPrimaryContainer = Color(0xFFE0E7FF),
            secondary = seed,
            surface = Color(0xFF121318),
            surfaceVariant = Color(0xFF1E2028)
        )
    } else {
        lightColorScheme(
            primary = seed,
            onPrimary = Color.White,
            primaryContainer = seed.copy(alpha = 0.16f),
            onPrimaryContainer = Color(0xFF1E1B4B),
            secondary = seed,
            surface = Color(0xFFF8FAFC),
            surfaceVariant = Color(0xFFEEF2F6)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AegisSuRootApp() {
    val context = LocalContext.current
    val db = remember { PolicyDbHelper(context) }
    val prefStore = remember { AppPreferences(context) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var uiSettings by remember { mutableStateOf(prefStore.load()) }
    val systemDark = isSystemInDarkTheme()
    val useDark = when (uiSettings.themeMode) {
        1 -> false
        2 -> true
        else -> systemDark
    }

    val colorScheme = remember(useDark, uiSettings.accentIndex) {
        buildThemeScheme(useDark, uiSettings.accentIndex)
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var status by remember {
        mutableStateOf(
            SystemStatus(RootFramework.NONE, "-", "-", "-", "-", "-", "-", "-", false)
        )
    }
    var apps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var modules by remember { mutableStateOf<List<RootModule>>(emptyList()) }
    var logs by remember { mutableStateOf<List<SuLogEntry>>(emptyList()) }
    var showRebootDialog by remember { mutableStateOf(false) }

    val customBgBitmap = remember(uiSettings.bgImagePath) {
        val p = uiSettings.bgImagePath
        if (!p.isNullOrBlank() && File(p).exists()) {
            BitmapFactory.decodeFile(p)?.asImageBitmap()
        } else null
    }

    fun updateSettings(newSettings: UiSettings) {
        uiSettings = newSettings
        prefStore.save(newSettings)
    }

    fun refreshAll() {
        scope.launch {
            status = withContext(Dispatchers.IO) { RootBackend.detectSystemStatus() }
            val policies = withContext(Dispatchers.IO) { db.getAllPolicies() }
            apps = withContext(Dispatchers.IO) {
                val pm = context.packageManager
                pm.getInstalledApplications(0)
                    .map { info ->
                        val p = policies[info.uid]
                        val isSys = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                        InstalledAppItem(
                            uid = info.uid,
                            packageName = info.packageName,
                            appName = pm.getApplicationLabel(info).toString(),
                            isSystem = isSys,
                            granted = p?.granted ?: false,
                            denyList = p?.denyList ?: false
                        )
                    }
                    .sortedWith(compareByDescending<InstalledAppItem> { it.granted }.thenBy { it.appName })
            }
            modules = withContext(Dispatchers.IO) { RootBackend.listModules() }
            logs = withContext(Dispatchers.IO) { db.getLogs() }
        }
    }

    val moduleZipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val msg = withContext(Dispatchers.IO) {
                    val tmpFile = File(context.cacheDir, "pending_module.zip")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        tmpFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    val res = RootBackend.installModuleZip(status.framework, tmpFile.absolutePath)
                    if (res.exitCode == 0) "模块刷入成功，重启后生效" else "刷入失败：${res.stderr}"
                }
                snackbarHostState.showSnackbar(msg)
                refreshAll()
            }
        }
    }

    LaunchedEffect(Unit) { refreshAll() }

    MaterialTheme(colorScheme = colorScheme) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface)
        ) {
            // Custom wallpaper layer
            if (customBgBitmap != null) {
                Image(
                    bitmap = customBgBitmap,
                    contentDescription = "Custom Wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            (if (useDark) Color.Black else Color.White)
                                .copy(alpha = uiSettings.bgDimAlpha)
                        )
                )
            } else {
                // Subtle KernelSU-inspired ambient gradient background
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                                    MaterialTheme.colorScheme.surface,
                                    MaterialTheme.colorScheme.surface
                                )
                            )
                        )
                )
            }

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = {
                    SnackbarHost(
                        hostState = snackbarHostState,
                        modifier = Modifier.padding(bottom = 104.dp)
                    )
                },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Transparent
                        ),
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "AegisSU",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 22.sp
                                )
                                Spacer(Modifier.width(8.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = "v2.0",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        },
                        actions = {
                            IconButton(onClick = { refreshAll() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "刷新")
                            }
                            IconButton(onClick = { showRebootDialog = true }) {
                                Icon(Icons.Default.PowerSettingsNew, contentDescription = "电源菜单")
                            }
                        }
                    )
                },
                floatingActionButton = {
                    if (selectedTab == 3) {
                        ExtendedFloatingActionButton(
                            onClick = { moduleZipPicker.launch(arrayOf("application/zip", "application/octet-stream")) },
                            icon = { Icon(Icons.Default.Add, null) },
                            text = { Text("刷入模块") },
                            modifier = Modifier.padding(bottom = 92.dp)
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = innerPadding.calculateTopPadding())
                ) {
                    val cardAlpha = uiSettings.glassBlurAlpha

                    when (selectedTab) {
                        0 -> HomeScreen(
                            status = status,
                            grantedCount = apps.count { it.granted },
                            moduleCount = modules.size,
                            cardAlpha = cardAlpha,
                            onGoPatch = { selectedTab = 1 },
                            onDeployDaemon = {
                                scope.launch {
                                    val soPath = "${context.applicationInfo.nativeLibraryDir}/libaegissu.so"
                                    val res = withContext(Dispatchers.IO) { RootBackend.deployNativeDaemon(soPath) }
                                    val msg = if (res.exitCode == 0) "AegisSU 原生守护进程已部署并启动" else "部署失败（需已有 Root 或先通过修补 Boot 刷入）"
                                    snackbarHostState.showSnackbar(msg)
                                    refreshAll()
                                }
                            }
                        )
                        1 -> BootPatcherScreen(
                            status = status,
                            cardAlpha = cardAlpha,
                            onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                        )
                        2 -> SuperuserScreen(
                            apps = apps,
                            framework = status.framework,
                            cardAlpha = cardAlpha,
                            onUpdate = { item, granted, denyList ->
                                scope.launch(Dispatchers.IO) {
                                    db.upsertPolicy(item.uid, item.packageName, item.appName, granted, denyList)
                                    RootBackend.writePolicyForDaemon(item.uid, granted)
                                    RootBackend.setDenyList(status.framework, item.packageName, denyList)
                                    refreshAll()
                                }
                            }
                        )
                        3 -> ModulesScreen(
                            modules = modules,
                            cardAlpha = cardAlpha,
                            onToggle = { mod, enable ->
                                scope.launch(Dispatchers.IO) {
                                    RootBackend.toggleModule(mod.id, enable)
                                    refreshAll()
                                }
                            },
                            onRemove = { mod, remove ->
                                scope.launch(Dispatchers.IO) {
                                    RootBackend.toggleRemoveModule(mod.id, remove)
                                    refreshAll()
                                }
                            }
                        )
                        4 -> SettingsAndLogsScreen(
                            settings = uiSettings,
                            logs = logs,
                            cardAlpha = cardAlpha,
                            onUpdateSettings = { updateSettings(it) },
                            onClearLogs = {
                                scope.launch(Dispatchers.IO) {
                                    db.clearLogs()
                                    refreshAll()
                                }
                            },
                            onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                        )
                    }

                    // KernelSU-style Liquid Floating Capsule Navigation Bar at bottom
                    LiquidBottomNavBar(
                        selectedIndex = selectedTab,
                        onSelect = { selectedTab = it },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }
            }
        }

        if (showRebootDialog) {
            AlertDialog(
                onDismissRequest = { showRebootDialog = false },
                title = { Text("系统电源菜单") },
                text = { Text("选择需要执行的重启模式（需超级用户权限）：") },
                confirmButton = {
                    Button(onClick = {
                        showRebootDialog = false
                        scope.launch(Dispatchers.IO) { RootBackend.reboot() }
                    }) { Text("重启系统") }
                },
                dismissButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(onClick = {
                            showRebootDialog = false
                            scope.launch(Dispatchers.IO) { RootBackend.reboot("recovery") }
                        }) { Text("Recovery") }
                        FilledTonalButton(onClick = {
                            showRebootDialog = false
                            scope.launch(Dispatchers.IO) { RootBackend.reboot("bootloader") }
                        }) { Text("Fastboot") }
                    }
                }
            )
        }
    }
}

@Composable
fun LiquidBottomNavBar(
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = remember {
        listOf(
            NavItem("主页", Icons.Filled.Home, Icons.Outlined.Home),
            NavItem("修补", Icons.Filled.BuildCircle, Icons.Outlined.BuildCircle),
            NavItem("超级用户", Icons.Filled.Security, Icons.Outlined.Security),
            NavItem("模块", Icons.Filled.Extension, Icons.Outlined.Extension),
            NavItem("设置", Icons.Filled.Settings, Icons.Outlined.Settings)
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(68.dp)
            .shadow(
                elevation = 20.dp,
                shape = RoundedCornerShape(36.dp),
                ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
            )
            .clip(RoundedCornerShape(36.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f),
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.28f),
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    )
                ),
                shape = RoundedCornerShape(36.dp)
            )
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        val tabWidth = maxWidth / items.size
        val indicatorOffset by animateDpAsState(
            targetValue = tabWidth * selectedIndex,
            animationSpec = spring(
                dampingRatio = 0.62f,
                stiffness = Spring.StiffnessLow
            ),
            label = "liquid_offset"
        )

        // Liquid morphing pill indicator
        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(tabWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(30.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.28f),
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(30.dp)
                )
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { idx, item ->
                val selected = idx == selectedIndex
                val scale by animateFloatAsState(
                    targetValue = if (selected) 1.08f else 0.95f,
                    animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
                    label = "icon_scale"
                )
                val contentColor by animateColorAsState(
                    targetValue = if (selected)
                        MaterialTheme.colorScheme.primary
                    else
                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
                    label = "nav_color"
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .scale(scale)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(idx) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.label,
                        tint = contentColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = item.label,
                        color = contentColor,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun GlassCard(
    alpha: Float,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = containerColor.copy(alpha = alpha),
        tonalElevation = 4.dp,
        border = androidx.compose.foundation.BorderStroke(
            0.8.dp,
            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
        )
    ) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun HomeScreen(
    status: SystemStatus,
    grantedCount: Int,
    moduleCount: Int,
    cardAlpha: Float,
    onGoPatch: () -> Unit,
    onDeployDaemon: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .padding(bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // KSU-style Hero Banner Card
        GlassCard(
            alpha = (cardAlpha + 0.1f).coerceAtMost(0.95f),
            containerColor = if (status.isRooted)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.errorContainer
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (status.isRooted)
                        MaterialTheme.colorScheme.primary
                    else
                        MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (status.isRooted) Icons.Default.VerifiedUser else Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (status.isRooted) "工作正常 · ${status.framework.displayName}" else "未安装 / 未激活 Root",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = if (status.isRooted)
                            "版本: ${status.frameworkVersion}  |  槽位: ${status.slotSuffix}"
                        else
                            "点击下方「修补 Boot 镜像」获取 Root 权限",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onGoPatch,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.BuildCircle, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (status.isRooted) "更新 / 修补镜像" else "修补 Boot 获取 Root")
                }
                FilledTonalButton(
                    onClick = onDeployDaemon,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("部署守护")
                }
            }
        }

        // Quick Stats Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GlassCard(alpha = cardAlpha, modifier = Modifier.weight(1f)) {
                Text("超级用户授权", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "$grantedCount 个应用",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            GlassCard(alpha = cardAlpha, modifier = Modifier.weight(1f)) {
                Text("系统模块", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "$moduleCount 个已加载",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Detailed System Info Card
        GlassCard(alpha = cardAlpha) {
            Text(
                text = "设备与内核环境",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))
            InfoRow("设备型号", status.deviceModel)
            InfoRow("系统版本", status.androidVersion)
            InfoRow("内核版本", status.kernelVersion)
            InfoRow("CPU 架构", status.abi)
            InfoRow("活动分区槽位", status.slotSuffix)
            InfoRow("SELinux 状态", status.selinuxMode)
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun BootPatcherScreen(
    status: SystemStatus,
    cardAlpha: Float,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedBootFile by remember { mutableStateOf<File?>(null) }
    var bootHeader by remember { mutableStateOf<BootHeaderInfo?>(null) }
    var patchLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var patchedPath by remember { mutableStateOf<String?>(null) }
    var isBusy by remember { mutableStateOf(false) }

    val bootPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isBusy = true
                val copied = withContext(Dispatchers.IO) {
                    val f = File(context.cacheDir, "selected_boot.img")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        f.outputStream().use { out -> input.copyTo(out) }
                    }
                    f
                }
                val hdr = withContext(Dispatchers.IO) { BootImagePatcher.parseBootImage(copied) }
                selectedBootFile = copied
                bootHeader = hdr
                patchLogs = listOf(
                    "[*] 已加载镜像 (${copied.length() / 1024} KB)",
                    if (hdr.isValid)
                        "[+] 校验通过: ANDROID! Boot Header v${hdr.headerVersion}, PageSize=${hdr.pageSize}, SHA256=${hdr.sha256.take(16)}..."
                    else
                        "[!] 警告: 文件未包含标准 ANDROID! 引导头，请确认是否为 boot.img / init_boot.img"
                )
                isBusy = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .padding(bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        GlassCard(alpha = cardAlpha) {
            Text(
                text = "修补 Boot / Init_Boot 镜像获取 Root",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "支持解析标准 Android Boot Image (v0~v4)，将 APK 内置的原生 AegisSU 守护二进制 (04755 SUID) 或 KernelSU 模块注入 Ramdisk 并输出到 Download 目录。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { bootPicker.launch(arrayOf("*/*")) },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("选择本地 boot.img")
                }

                if (status.isRooted) {
                    FilledTonalButton(
                        onClick = {
                            scope.launch {
                                isBusy = true
                                val dest = File(context.cacheDir, "extracted_boot.img")
                                val res = withContext(Dispatchers.IO) {
                                    RootBackend.dumpActiveBootPartition(dest)
                                }
                                if (res.exitCode == 0 && dest.exists()) {
                                    selectedBootFile = dest
                                    bootHeader = withContext(Dispatchers.IO) {
                                        BootImagePatcher.parseBootImage(dest)
                                    }
                                    patchLogs = listOf("[+] 已从当前设备活动分区直接提取 boot.img (${dest.length() / 1024} KB)")
                                } else {
                                    onShowMessage(res.stderr.ifBlank { "提取失败" })
                                }
                                isBusy = false
                            }
                        },
                        enabled = !isBusy,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("提取当前分区")
                    }
                }
            }
        }

        bootHeader?.let { hdr ->
            GlassCard(alpha = cardAlpha) {
                Text(
                    text = "镜像头部解析详情",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                InfoRow("格式校验", if (hdr.isValid) "有效 (ANDROID!)" else "非标准格式")
                InfoRow("Header 版本", "v${hdr.headerVersion}")
                InfoRow("Kernel 大小", "${hdr.kernelSize / 1024} KB")
                InfoRow("Ramdisk 大小", "${hdr.ramdiskSize / 1024} KB")
                InfoRow("页大小 (PageSize)", "${hdr.pageSize} Bytes")
                InfoRow("SHA-256", hdr.sha256.take(20) + "...")
                if (hdr.cmdline.isNotBlank()) {
                    InfoRow("Cmdline", hdr.cmdline)
                }

                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val file = selectedBootFile ?: return@Button
                            scope.launch {
                                isBusy = true
                                val outcome = withContext(Dispatchers.IO) {
                                    BootImagePatcher.patchBootImage(context, file, hdr)
                                }
                                patchLogs = outcome.logs
                                if (outcome.success) {
                                    patchedPath = outcome.outputPath
                                    onShowMessage("修补完成！已保存至系统 Download 目录")
                                } else {
                                    onShowMessage("修补失败，请查看下方终端日志")
                                }
                                isBusy = false
                            }
                        },
                        enabled = !isBusy && hdr.isValid,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.AutoFixHigh, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isBusy) "正在修补..." else "开始修补生成 Root 镜像")
                    }

                    if (status.isRooted && patchedPath != null) {
                        FilledTonalButton(
                            onClick = {
                                val p = patchedPath ?: return@FilledTonalButton
                                scope.launch {
                                    isBusy = true
                                    val res = withContext(Dispatchers.IO) {
                                        RootBackend.flashBootPartition(File(p))
                                    }
                                    if (res.exitCode == 0) {
                                        onShowMessage("已成功刷入活动 boot 分区，重启生效")
                                    } else {
                                        onShowMessage("直接刷入失败: ${res.stderr}")
                                    }
                                    isBusy = false
                                }
                            },
                            enabled = !isBusy,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("直接刷入分区")
                        }
                    }
                }
            }
        }

        if (patchLogs.isNotEmpty()) {
            GlassCard(
                alpha = 0.90f,
                containerColor = Color(0xFF0F172A)
            ) {
                Text(
                    text = "修补终端输出",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                patchLogs.forEach { line ->
                    Text(
                        text = line,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color(0xFFE2E8F0),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SuperuserScreen(
    apps: List<InstalledAppItem>,
    framework: RootFramework,
    cardAlpha: Float,
    onUpdate: (InstalledAppItem, Boolean, Boolean) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var showSystemApps by remember { mutableStateOf(false) }

    val filtered = remember(apps, search, showSystemApps) {
        apps.filter { item ->
            (showSystemApps || !item.isSystem) &&
                (search.isBlank() ||
                    item.appName.contains(search, ignoreCase = true) ||
                    item.packageName.contains(search, ignoreCase = true))
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("搜索应用名称或包名") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = showSystemApps,
                onClick = { showSystemApps = !showSystemApps },
                label = { Text("系统应用") }
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.uid }) { item ->
                GlassCard(alpha = cardAlpha) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.appName, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${item.packageName} · UID ${item.uid}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = item.granted,
                            onCheckedChange = { onUpdate(item, it, if (it) false else item.denyList) }
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "卸载模块挂载 / 隐藏 Root (DenyList)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Checkbox(
                            checked = item.denyList,
                            onCheckedChange = { onUpdate(item, if (it) false else item.granted, it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModulesScreen(
    modules: List<RootModule>,
    cardAlpha: Float,
    onToggle: (RootModule, Boolean) -> Unit,
    onRemove: (RootModule, Boolean) -> Unit
) {
    if (modules.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            GlassCard(alpha = cardAlpha) {
                Text(
                    text = "暂无已安装的模块",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "点击右下角「刷入模块」选择本地 Magisk / KernelSU 模块 (.zip) 安装，模块目录位于 /data/adb/modules。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(modules, key = { it.id }) { mod ->
            GlassCard(alpha = cardAlpha) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${mod.name} (${mod.version})", fontWeight = FontWeight.Bold)
                        Text(
                            text = "作者：${mod.author} · ID: ${mod.id}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = mod.enabled, onCheckedChange = { onToggle(mod, it) })
                }
                if (mod.description.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(mod.description, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { onRemove(mod, !mod.pendingRemove) }) {
                        Text(if (mod.pendingRemove) "取消卸载 (重启生效)" else "标记卸载")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsAndLogsScreen(
    settings: UiSettings,
    logs: List<SuLogEntry>,
    cardAlpha: Float,
    onUpdateSettings: (UiSettings) -> Unit,
    onClearLogs: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fmt = remember { SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()) }

    val wallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val savedFile = withContext(Dispatchers.IO) {
                    val dest = File(context.filesDir, "custom_wallpaper_${System.currentTimeMillis()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        dest.outputStream().use { out -> input.copyTo(out) }
                    }
                    dest
                }
                if (savedFile.exists() && savedFile.length() > 0) {
                    onUpdateSettings(settings.copy(bgImagePath = savedFile.absolutePath))
                    onShowMessage("自定义背景壁纸已应用")
                }
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard(alpha = cardAlpha) {
                Text(
                    text = "个性化背景与毛玻璃视觉",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { wallpaperPicker.launch(arrayOf("image/*")) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Wallpaper, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("从相册选择背景图")
                    }
                    if (!settings.bgImagePath.isNullOrBlank()) {
                        OutlinedButton(
                            onClick = {
                                onUpdateSettings(settings.copy(bgImagePath = null))
                                onShowMessage("已恢复默认渐变背景")
                            },
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("清除背景")
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text(
                    text = "背景遮罩浓度: ${(settings.bgDimAlpha * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = settings.bgDimAlpha,
                    onValueChange = { onUpdateSettings(settings.copy(bgDimAlpha = it)) },
                    valueRange = 0.10f..0.85f
                )

                Text(
                    text = "卡片不透明度 (液态玻璃感): ${(settings.glassBlurAlpha * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = settings.glassBlurAlpha,
                    onValueChange = { onUpdateSettings(settings.copy(glassBlurAlpha = it)) },
                    valueRange = 0.50f..0.96f
                )
            }
        }

        item {
            GlassCard(alpha = cardAlpha) {
                Text(
                    text = "主题色彩与外观模式",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val modes = listOf(0 to "跟随系统", 1 to "浅色", 2 to "深色")
                    modes.forEach { (idx, label) ->
                        FilterChip(
                            selected = settings.themeMode == idx,
                            onClick = { onUpdateSettings(settings.copy(themeMode = idx)) },
                            label = { Text(label) }
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("强调色方案", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val names = listOf("靛蓝", "翡翠", "绯红", "琥珀")
                    names.forEachIndexed { idx, name ->
                        FilterChip(
                            selected = settings.accentIndex == idx,
                            onClick = { onUpdateSettings(settings.copy(accentIndex = idx)) },
                            label = { Text(name) }
                        )
                    }
                }
            }
        }

        item {
            GlassCard(alpha = cardAlpha) {
                Text(
                    text = "超级用户安全策略",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("授权弹窗超时自动拒绝", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(10, 15, 30).forEach { sec ->
                            FilterChip(
                                selected = settings.suTimeoutSec == sec,
                                onClick = { onUpdateSettings(settings.copy(suTimeoutSec = sec)) },
                                label = { Text("${sec}s") }
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SU 提权审计日志 (${logs.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (logs.isNotEmpty()) {
                    TextButton(onClick = onClearLogs) {
                        Text("清空日志")
                    }
                }
            }
        }

        if (logs.isEmpty()) {
            item {
                GlassCard(alpha = cardAlpha) {
                    Text(
                        text = "暂无 SU 提权调用记录",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(logs, key = { it.id }) { entry ->
                GlassCard(alpha = cardAlpha) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(entry.packageName, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (entry.allowed) "允许" else "拒绝",
                            color = if (entry.allowed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = entry.command,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "UID ${entry.uid} · ${fmt.format(Date(entry.timestamp))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
