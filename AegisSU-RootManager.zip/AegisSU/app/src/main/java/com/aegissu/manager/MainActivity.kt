package com.aegissu.manager

import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aegissu.manager.core.*
import com.aegissu.manager.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class InstalledAppItem(
    val uid: Int,
    val packageName: String,
    val appName: String,
    val isSystem: Boolean,
    val granted: Boolean,
    val denyList: Boolean
)

data class KsuNavItem(
    val label: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        setContent {
            AegisSuRootApp()
        }
    }
}

private val AccentPalettes = listOf(
    Color(0xFF2563EB), // KernelSU Blue
    Color(0xFF059669), // Emerald
    Color(0xFFE11D48), // Crimson
    Color(0xFFD97706)  // Amber
)

fun buildThemeScheme(darkTheme: Boolean, accentIndex: Int): ColorScheme {
    val seed = AccentPalettes.getOrElse(accentIndex) { AccentPalettes[0] }
    return if (darkTheme) {
        darkColorScheme(
            primary = seed,
            onPrimary = Color.White,
            primaryContainer = Color(0xFF1E293B),
            onPrimaryContainer = Color(0xFF93C5FD),
            background = Color(0xFF0B0C0E),
            surface = Color(0xFF16181D),
            surfaceVariant = Color(0xFF22252C),
            onSurface = Color(0xFFF3F4F6),
            onSurfaceVariant = Color(0xFF9CA3AF)
        )
    } else {
        lightColorScheme(
            primary = seed,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFEFF6FF),
            onPrimaryContainer = seed,
            background = Color(0xFFF3F4F6),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE5E7EB),
            onSurface = Color(0xFF111827),
            onSurfaceVariant = Color(0xFF6B7280)
        )
    }
}

fun decodeSampledBitmap(path: String, reqWidth: Int = 1080, reqHeight: Int = 2400): ImageBitmap? {
    return try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        var inSampleSize = 1
        val (height, width) = opts.outHeight to opts.outWidth
        if (height > reqHeight || width > reqWidth) {
            val halfH = height / 2
            val halfW = width / 2
            while (halfH / inSampleSize >= reqHeight && halfW / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        val decodeOpts = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        BitmapFactory.decodeFile(path, decodeOpts)?.asImageBitmap()
    } catch (_: Exception) {
        null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AegisSuRootApp() {
    val context = LocalContext.current
    val db = remember { PolicyDbHelper(context) }
    val prefStore = remember { AppPreferences(context) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var uiSettings by remember { mutableStateOf(prefStore.load()) }
    val systemDark = isSystemInDarkTheme()
    val useDark = when (uiSettings.themeMode) {
        1 -> false
        2 -> true
        else -> systemDark
    }

    val colorScheme = remember(useDark, uiSettings.accentIndex) {
        buildThemeScheme(useDark, uiSettings.accentIndex)
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var showBootPatchSheet by remember { mutableStateOf(false) }

    var status by remember {
        mutableStateOf(
            SystemStatus(RootFramework.NONE, "-", "-", "-", "-", "-", "-", "-", false)
        )
    }
    var apps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var modules by remember { mutableStateOf<List<RootModule>>(emptyList()) }
    var logs by remember { mutableStateOf<List<SuLogEntry>>(emptyList()) }
    var showRebootDialog by remember { mutableStateOf(false) }
    var customBgBitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(uiSettings.bgImagePath) {
        val p = uiSettings.bgImagePath
        customBgBitmap = if (!p.isNullOrBlank() && File(p).exists()) {
            withContext(Dispatchers.IO) { decodeSampledBitmap(p) }
        } else null
    }

    fun updateSettings(newSettings: UiSettings) {
        uiSettings = newSettings
        prefStore.save(newSettings)
    }

    fun refreshAll() {
        scope.launch {
            val statusDeferred = async(Dispatchers.IO) { RootBackend.detectSystemStatus() }
            val policiesDeferred = async(Dispatchers.IO) { db.getAllPolicies() }
            val modulesDeferred = async(Dispatchers.IO) { RootBackend.listModules() }
            val logsDeferred = async(Dispatchers.IO) { db.getLogs() }
            val appsDeferred = async(Dispatchers.IO) {
                val pm = context.packageManager
                val policies = policiesDeferred.await()
                pm.getInstalledApplications(0)
                    .map { info ->
                        val p = policies[info.uid]
                        InstalledAppItem(
                            uid = info.uid,
                            packageName = info.packageName,
                            appName = pm.getApplicationLabel(info).toString(),
                            isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                            granted = p?.granted ?: false,
                            denyList = p?.denyList ?: false
                        )
                    }
                    .sortedWith(compareByDescending<InstalledAppItem> { it.granted }.thenBy { it.appName })
            }

            status = statusDeferred.await()
            modules = modulesDeferred.await()
            logs = logsDeferred.await()
            apps = appsDeferred.await()
        }
    }

    val moduleZipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val msg = withContext(Dispatchers.IO) {
                    val tmpFile = File(context.cacheDir, "pending_module.zip")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        tmpFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    val res = RootBackend.installModuleZip(status.framework, tmpFile.absolutePath)
                    if (res.exitCode == 0) "模块刷入成功，重启后生效" else "刷入失败：${res.stderr}"
                }
                snackbarHostState.showSnackbar(msg)
                refreshAll()
            }
        }
    }

    LaunchedEffect(Unit) { refreshAll() }

    val grantedCount = remember(apps) { apps.count { it.granted } }

    MaterialTheme(colorScheme = colorScheme) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (customBgBitmap != null) {
                Image(
                    bitmap = customBgBitmap!!,
                    contentDescription = "Wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            (if (useDark) Color.Black else Color.White)
                                .copy(alpha = uiSettings.bgDimAlpha)
                        )
                )
            }

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = {
                    SnackbarHost(
                        hostState = snackbarHostState,
                        modifier = Modifier.padding(bottom = 100.dp)
                    )
                },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                        title = {
                            Text(
                                text = when (selectedTab) {
                                    0 -> "AegisSU"
                                    1 -> "超级用户"
                                    2 -> "模块"
                                    else -> "设置与日志"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp
                            )
                        },
                        actions = {
                            IconButton(onClick = { refreshAll() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "刷新")
                            }
                            IconButton(onClick = { showRebootDialog = true }) {
                                Icon(Icons.Default.PowerSettingsNew, contentDescription = "电源")
                            }
                        }
                    )
                },
                floatingActionButton = {
                    if (selectedTab == 2) {
                        FloatingActionButton(
                            onClick = { moduleZipPicker.launch(arrayOf("application/zip", "application/octet-stream")) },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier.padding(bottom = 92.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "安装模块")
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = innerPadding.calculateTopPadding())
                ) {
                    val cardAlpha = if (customBgBitmap != null) uiSettings.cardOpacity else 1f

                    when (selectedTab) {
                        0 -> HomeScreen(
                            status = status,
                            grantedCount = grantedCount,
                            moduleCount = modules.size,
                            cardAlpha = cardAlpha,
                            onOpenPatcher = { showBootPatchSheet = true },
                            onDeployDaemon = {
                                scope.launch {
                                    val soPath = "${context.applicationInfo.nativeLibraryDir}/libaegissu.so"
                                    val res = withContext(Dispatchers.IO) { RootBackend.deployNativeDaemon(soPath) }
                                    val msg = if (res.exitCode == 0) "原生守护进程已启动" else "部署失败：当前设备未激活 Root"
                                    snackbarHostState.showSnackbar(msg)
                                    refreshAll()
                                }
                            }
                        )
                        1 -> SuperuserScreen(
                            apps = apps,
                            cardAlpha = cardAlpha,
                            onUpdate = { item, granted, denyList ->
                                scope.launch(Dispatchers.IO) {
                                    db.upsertPolicy(item.uid, item.packageName, item.appName, granted, denyList)
                                    RootBackend.writePolicyForDaemon(item.uid, granted)
                                    RootBackend.setDenyList(status.framework, item.packageName, denyList)
                                    refreshAll()
                                }
                            }
                        )
                        2 -> ModulesScreen(
                            modules = modules,
                            cardAlpha = cardAlpha,
                            onToggle = { mod, enable ->
                                scope.launch(Dispatchers.IO) {
                                    RootBackend.toggleModule(mod.id, enable)
                                    refreshAll()
                                }
                            },
                            onRemove = { mod, remove ->
                                scope.launch(Dispatchers.IO) {
                                    RootBackend.toggleRemoveModule(mod.id, remove)
                                    refreshAll()
                                }
                            }
                        )
                        3 -> SettingsAndLogsScreen(
                            settings = uiSettings,
                            logs = logs,
                            cardAlpha = cardAlpha,
                            onUpdateSettings = { updateSettings(it) },
                            onClearLogs = {
                                scope.launch(Dispatchers.IO) {
                                    db.clearLogs()
                                    refreshAll()
                                }
                            },
                            onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                        )
                    }

                    // Exact KernelSU-style 4-tab Liquid Capsule Navigation Bar
                    KsuLiquidBottomBar(
                        selectedIndex = selectedTab,
                        grantedCount = grantedCount,
                        moduleCount = modules.size,
                        darkTheme = useDark,
                        onSelect = { selectedTab = it },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(horizontal = 24.dp, vertical = 14.dp)
                    )
                }
            }
        }

        if (showBootPatchSheet) {
            ModalBottomSheet(
                onDismissRequest = { showBootPatchSheet = false },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                BootPatcherSheetContent(
                    status = status,
                    onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                )
            }
        }

        if (showRebootDialog) {
            AlertDialog(
                onDismissRequest = { showRebootDialog = false },
                title = { Text("电源菜单") },
                text = { Text("选择要执行的重启方式") },
                confirmButton = {
                    Button(onClick = {
                        showRebootDialog = false
                        scope.launch(Dispatchers.IO) { RootBackend.reboot() }
                    }) { Text("重启系统") }
                },
                dismissButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = {
                            showRebootDialog = false
                            scope.launch(Dispatchers.IO) { RootBackend.reboot("recovery") }
                        }) { Text("Recovery") }
                        FilledTonalButton(onClick = {
                            showRebootDialog = false
                            scope.launch(Dispatchers.IO) { RootBackend.reboot("bootloader") }
                        }) { Text("Fastboot") }
                    }
                }
            )
        }
    }
}

@Composable
fun KsuLiquidBottomBar(
    selectedIndex: Int,
    grantedCount: Int,
    moduleCount: Int,
    darkTheme: Boolean,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        KsuNavItem("主页", Icons.Filled.Home),
        KsuNavItem("超级用户", Icons.Filled.Security, grantedCount),
        KsuNavItem("模块", Icons.Filled.Extension, moduleCount),
        KsuNavItem("设置", Icons.Filled.Settings)
    )

    val barBg = if (darkTheme) Color(0xFF1F2229).copy(alpha = 0.94f) else Color.White.copy(alpha = 0.94f)
    val pillBg = if (darkTheme) Color.White.copy(alpha = 0.14f) else Color(0xFFE5E7EB).copy(alpha = 0.85f)
    val borderColor = if (darkTheme) Color.White.copy(alpha = 0.12f) else Color.Black.copy(alpha = 0.06f)
    val inactiveColor = if (darkTheme) Color(0xFFE5E7EB) else Color(0xFF111827)
    val activeColor = MaterialTheme.colorScheme.primary

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(66.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(34.dp),
                ambientColor = Color.Black.copy(alpha = 0.18f),
                spotColor = Color.Black.copy(alpha = 0.18f)
            )
            .clip(RoundedCornerShape(34.dp))
            .background(barBg)
            .border(0.8.dp, borderColor, RoundedCornerShape(34.dp))
            .padding(5.dp)
    ) {
        val tabWidth = maxWidth / items.size
        val indicatorOffset by animateDpAsState(
            targetValue = tabWidth * selectedIndex,
            animationSpec = spring(
                dampingRatio = 0.72f,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "ksu_pill_offset"
        )

        // Sliding liquid pill indicator matching KSU screenshot
        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(tabWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(29.dp))
                .background(pillBg)
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { idx, item ->
                val selected = idx == selectedIndex
                val tint by animateColorAsState(
                    targetValue = if (selected) activeColor else inactiveColor,
                    label = "ksu_tab_tint"
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(idx) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(contentAlignment = Alignment.TopEnd) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = tint,
                            modifier = Modifier
                                .padding(horizontal = 6.dp)
                                .size(23.dp)
                        )
                        if (item.badgeCount > 0) {
                            Box(
                                modifier = Modifier
                                    .offset(x = 2.dp, y = (-3).dp)
                                    .defaultMinSize(minWidth = 17.dp, minHeight = 17.dp)
                                    .clip(CircleShape)
                                    .background(activeColor)
                                    .padding(horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (item.badgeCount > 99) "99+" else item.badgeCount.toString(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 10.sp
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = item.label,
                        color = tint,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun CleanCard(
    alpha: Float,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = containerColor.copy(alpha = alpha),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
    ) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun HomeScreen(
    status: SystemStatus,
    grantedCount: Int,
    moduleCount: Int,
    cardAlpha: Float,
    onOpenPatcher: () -> Unit,
    onDeployDaemon: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .padding(bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CleanCard(
            alpha = cardAlpha,
            containerColor = if (status.isRooted)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.surface
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            if (status.isRooted) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (status.isRooted) Icons.Default.VerifiedUser else Icons.Default.GppMaybe,
                        contentDescription = null,
                        tint = if (status.isRooted) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (status.isRooted) "工作中 · ${status.framework.displayName}" else "未安装",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (status.isRooted)
                            "版本: ${status.frameworkVersion} · 槽位: ${status.slotSuffix}"
                        else
                            "点击下方按钮修补 boot.img 获取 Root 权限",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onOpenPatcher,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.BuildCircle, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("修补 Boot 镜像")
                }
                FilledTonalButton(
                    onClick = onDeployDaemon,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("部署守护")
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CleanCard(alpha = cardAlpha, modifier = Modifier.weight(1f)) {
                Text("超级用户", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "$grantedCount",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            CleanCard(alpha = cardAlpha, modifier = Modifier.weight(1f)) {
                Text("模块", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "$moduleCount",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        CleanCard(alpha = cardAlpha) {
            Text("设备信息", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            InfoRow("设备型号", status.deviceModel)
            InfoRow("Android 版本", status.androidVersion)
            InfoRow("内核版本", status.kernelVersion)
            InfoRow("架构", status.abi)
            InfoRow("当前槽位", status.slotSuffix)
            InfoRow("SELinux", status.selinuxMode)
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(12.dp))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun BootPatcherSheetContent(
    status: SystemStatus,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedBootFile by remember { mutableStateOf<File?>(null) }
    var bootHeader by remember { mutableStateOf<BootHeaderInfo?>(null) }
    var patchLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var patchedPath by remember { mutableStateOf<String?>(null) }
    var isBusy by remember { mutableStateOf(false) }

    val bootPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isBusy = true
                val copied = withContext(Dispatchers.IO) {
                    val f = File(context.cacheDir, "selected_boot.img")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        f.outputStream().use { out -> input.copyTo(out) }
                    }
                    f
                }
                val hdr = withContext(Dispatchers.IO) { BootImagePatcher.parseBootImage(copied) }
                selectedBootFile = copied
                bootHeader = hdr
                patchLogs = listOf(
                    "[*] 加载镜像: ${copied.length() / 1024} KB",
                    if (hdr.isValid) "[+] 头部有效: Boot Header v${hdr.headerVersion}, Page=${hdr.pageSize}"
                    else "[!] 无效镜像：未检测到 ANDROID! 魔数头"
                )
                isBusy = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("修补 Boot / Init_Boot 镜像", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "选择官方刷机包内的 boot.img 或 init_boot.img，注入原生 SU 守护二进制后输出到 Download 目录。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { bootPicker.launch(arrayOf("*/*")) },
                enabled = !isBusy,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("选择 boot.img")
            }
            if (status.isRooted) {
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            isBusy = true
                            val dest = File(context.cacheDir, "extracted_boot.img")
                            val res = withContext(Dispatchers.IO) { RootBackend.dumpActiveBootPartition(dest) }
                            if (res.exitCode == 0 && dest.exists()) {
                                selectedBootFile = dest
                                bootHeader = withContext(Dispatchers.IO) { BootImagePatcher.parseBootImage(dest) }
                                patchLogs = listOf("[+] 已提取当前槽位分区镜像 (${dest.length() / 1024} KB)")
                            } else {
                                onShowMessage(res.stderr.ifBlank { "提取失败" })
                            }
                            isBusy = false
                        }
                    },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("提取当前分区")
                }
            }
        }

        bootHeader?.let { hdr ->
            if (hdr.isValid) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val file = selectedBootFile ?: return@Button
                            scope.launch {
                                isBusy = true
                                val outcome = withContext(Dispatchers.IO) { BootImagePatcher.patchBootImage(context, file, hdr) }
                                patchLogs = outcome.logs
                                if (outcome.success) {
                                    patchedPath = outcome.outputPath
                                    onShowMessage("修补完成！已保存至 Download 目录")
                                }
                                isBusy = false
                            }
                        },
                        enabled = !isBusy,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isBusy) "修补中..." else "开始修补")
                    }
                    if (status.isRooted && patchedPath != null) {
                        FilledTonalButton(
                            onClick = {
                                val p = patchedPath ?: return@FilledTonalButton
                                scope.launch {
                                    isBusy = true
                                    val res = withContext(Dispatchers.IO) { RootBackend.flashBootPartition(File(p)) }
                                    onShowMessage(if (res.exitCode == 0) "刷入成功，重启生效" else "刷入失败: ${res.stderr}")
                                    isBusy = false
                                }
                            },
                            enabled = !isBusy,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("直接刷入")
                        }
                    }
                }
            }
        }

        if (patchLogs.isNotEmpty()) {
            Surface(
                color = Color(0xFF0F172A),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    patchLogs.forEach { line ->
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFE2E8F0))
                    }
                }
            }
        }
    }
}

@Composable
fun SuperuserScreen(
    apps: List<InstalledAppItem>,
    cardAlpha: Float,
    onUpdate: (InstalledAppItem, Boolean, Boolean) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var showSystemApps by remember { mutableStateOf(false) }

    val filtered = remember(apps, search, showSystemApps) {
        apps.filter { item ->
            (showSystemApps || !item.isSystem) &&
                (search.isBlank() ||
                    item.appName.contains(search, ignoreCase = true) ||
                    item.packageName.contains(search, ignoreCase = true))
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("搜索应用") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = showSystemApps,
                onClick = { showSystemApps = !showSystemApps },
                label = { Text("系统") }
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.uid }) { item ->
                CleanCard(alpha = cardAlpha) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.appName, fontWeight = FontWeight.SemiBold)
                            Text("${item.packageName} · UID ${item.uid}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = item.granted,
                            onCheckedChange = { onUpdate(item, it, if (it) false else item.denyList) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DenyList / 隐藏 Root", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Checkbox(
                            checked = item.denyList,
                            onCheckedChange = { onUpdate(item, if (it) false else item.granted, it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModulesScreen(
    modules: List<RootModule>,
    cardAlpha: Float,
    onToggle: (RootModule, Boolean) -> Unit,
    onRemove: (RootModule, Boolean) -> Unit
) {
    if (modules.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            CleanCard(alpha = cardAlpha) {
                Text("暂无已安装的模块", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("点击右下角 + 按钮选择本地模块 ZIP 安装", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(modules, key = { it.id }) { mod ->
            CleanCard(alpha = cardAlpha) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${mod.name} (${mod.version})", fontWeight = FontWeight.Bold)
                        Text("作者：${mod.author}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = mod.enabled, onCheckedChange = { onToggle(mod, it) })
                }
                if (mod.description.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(mod.description, style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { onRemove(mod, !mod.pendingRemove) }) {
                        Text(if (mod.pendingRemove) "取消卸载" else "卸载")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsAndLogsScreen(
    settings: UiSettings,
    logs: List<SuLogEntry>,
    cardAlpha: Float,
    onUpdateSettings: (UiSettings) -> Unit,
    onClearLogs: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fmt = remember { SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()) }

    val wallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val savedFile = withContext(Dispatchers.IO) {
                    val dest = File(context.filesDir, "custom_wallpaper_${System.currentTimeMillis()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        dest.outputStream().use { out -> input.copyTo(out) }
                    }
                    dest
                }
                if (savedFile.exists() && savedFile.length() > 0) {
                    onUpdateSettings(settings.copy(bgImagePath = savedFile.absolutePath))
                    onShowMessage("自定义背景已应用")
                }
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            CleanCard(alpha = cardAlpha) {
                Text("背景与外观设置", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { wallpaperPicker.launch(arrayOf("image/*")) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Wallpaper, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("选择背景图片")
                    }
                    if (!settings.bgImagePath.isNullOrBlank()) {
                        OutlinedButton(
                            onClick = {
                                onUpdateSettings(settings.copy(bgImagePath = null))
                                onShowMessage("已恢复默认背景")
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("恢复默认") }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("背景遮罩浓度: ${(settings.bgDimAlpha * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = settings.bgDimAlpha,
                    onValueChange = { onUpdateSettings(settings.copy(bgDimAlpha = it)) },
                    valueRange = 0.05f..0.85f
                )
                Text("卡片透明度: ${(settings.cardOpacity * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = settings.cardOpacity,
                    onValueChange = { onUpdateSettings(settings.copy(cardOpacity = it)) },
                    valueRange = 0.60f..1.00f
                )
            }
        }

        item {
            CleanCard(alpha = cardAlpha) {
                Text("主题与强调色", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "跟随系统", 1 to "浅色", 2 to "深色").forEach { (idx, label) ->
                        FilterChip(
                            selected = settings.themeMode == idx,
                            onClick = { onUpdateSettings(settings.copy(themeMode = idx)) },
                            label = { Text(label) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("KSU蓝", "翡翠", "绯红", "琥珀").forEachIndexed { idx, name ->
                        FilterChip(
                            selected = settings.accentIndex == idx,
                            onClick = { onUpdateSettings(settings.copy(accentIndex = idx)) },
                            label = { Text(name) }
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SU 审计日志 (${logs.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                if (logs.isNotEmpty()) TextButton(onClick = onClearLogs) { Text("清空") }
            }
        }

        if (logs.isEmpty()) {
            item {
                CleanCard(alpha = cardAlpha) {
                    Text("暂无提权记录", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(logs, key = { it.id }) { entry ->
                CleanCard(alpha = cardAlpha) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(entry.packageName, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (entry.allowed) "允许" else "拒绝",
                            color = if (entry.allowed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    Text(entry.command, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                    Text("UID ${entry.uid} · ${fmt.format(Date(entry.timestamp))}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
