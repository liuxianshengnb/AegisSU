package com.aegissu.manager

import android.content.pm.ApplicationInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aegissu.manager.core.*
import com.aegissu.manager.data.AppPolicy
import com.aegissu.manager.data.PolicyDbHelper
import com.aegissu.manager.data.SuLogEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class InstalledAppItem(
    val uid: Int,
    val packageName: String,
    val appName: String,
    val granted: Boolean,
    val denyList: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AegisSuApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AegisSuApp() {
    val context = LocalContext.current
    val db = remember { PolicyDbHelper(context) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedTab by remember { mutableIntStateOf(0) }
    var status by remember {
        mutableStateOf(SystemStatus(RootFramework.NONE, "-", "-", "-", false))
    }
    var apps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var modules by remember { mutableStateOf<List<RootModule>>(emptyList()) }
    var logs by remember { mutableStateOf<List<SuLogEntry>>(emptyList()) }
    var showRebootDialog by remember { mutableStateOf(false) }

    fun refreshAll() {
        scope.launch {
            status = withContext(Dispatchers.IO) { RootBackend.detectSystemStatus() }
            val policies: Map<Int, AppPolicy> = withContext(Dispatchers.IO) { db.getAllPolicies() }
            apps = withContext(Dispatchers.IO) {
                val pm = context.packageManager
                pm.getInstalledApplications(0)
                    .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                    .map { info ->
                        val p = policies[info.uid]
                        InstalledAppItem(
                            uid = info.uid,
                            packageName = info.packageName,
                            appName = pm.getApplicationLabel(info).toString(),
                            granted = p?.granted ?: false,
                            denyList = p?.denyList ?: false
                        )
                    }
                    .sortedBy { it.appName }
            }
            modules = withContext(Dispatchers.IO) { RootBackend.listModules() }
            logs = withContext(Dispatchers.IO) { db.getLogs() }
        }
    }

    val modulePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val msg = withContext(Dispatchers.IO) {
                    val tmpFile = File(context.cacheDir, "pending_module.zip")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        tmpFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    val res = RootBackend.installModuleZip(status.framework, tmpFile.absolutePath)
                    if (res.exitCode == 0) "模块刷入成功，重启后生效" else "刷入失败：${res.stderr}"
                }
                snackbarHostState.showSnackbar(msg)
                refreshAll()
            }
        }
    }

    LaunchedEffect(Unit) { refreshAll() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("AegisSU", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { refreshAll() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "刷新")
                    }
                    IconButton(onClick = { showRebootDialog = true }) {
                        Icon(Icons.Default.PowerSettingsNew, contentDescription = "重启")
                    }
                }
            )
        },
        floatingActionButton = {
            if (selectedTab == 2) {
                FloatingActionButton(onClick = { modulePicker.launch(arrayOf("application/zip")) }) {
                    Icon(Icons.Default.Add, contentDescription = "安装模块")
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("概览") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Security, null) },
                    label = { Text("超级用户") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Extension, null) },
                    label = { Text("模块") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, null) },
                    label = { Text("日志") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> HomeScreen(status, apps.count { it.granted }, modules.size)
                1 -> SuperuserScreen(
                    apps = apps,
                    framework = status.framework,
                    onUpdate = { item, granted, denyList ->
                        scope.launch(Dispatchers.IO) {
                            db.upsertPolicy(item.uid, item.packageName, item.appName, granted, denyList)
                            RootBackend.writePolicyForDaemon(item.uid, granted)
                            RootBackend.setDenyList(status.framework, item.packageName, denyList)
                            refreshAll()
                        }
                    }
                )
                2 -> ModulesScreen(
                    modules = modules,
                    onToggle = { mod, enable ->
                        scope.launch(Dispatchers.IO) {
                            RootBackend.toggleModule(mod.id, enable)
                            refreshAll()
                        }
                    },
                    onRemove = { mod, remove ->
                        scope.launch(Dispatchers.IO) {
                            RootBackend.toggleRemoveModule(mod.id, remove)
                            refreshAll()
                        }
                    }
                )
                3 -> LogsScreen(
                    logs = logs,
                    onClear = {
                        scope.launch(Dispatchers.IO) {
                            db.clearLogs()
                            refreshAll()
                        }
                    }
                )
            }
        }
    }

    if (showRebootDialog) {
        AlertDialog(
            onDismissRequest = { showRebootDialog = false },
            title = { Text("电源菜单") },
            text = { Text("选择要执行的重启模式") },
            confirmButton = {
                TextButton(onClick = {
                    showRebootDialog = false
                    scope.launch(Dispatchers.IO) { RootBackend.reboot() }
                }) { Text("重启系统") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        showRebootDialog = false
                        scope.launch(Dispatchers.IO) { RootBackend.reboot("recovery") }
                    }) { Text("Recovery") }
                    TextButton(onClick = {
                        showRebootDialog = false
                        scope.launch(Dispatchers.IO) { RootBackend.reboot("bootloader") }
                    }) { Text("Bootloader") }
                }
            }
        )
    }
}

@Composable
fun HomeScreen(status: SystemStatus, grantedCount: Int, moduleCount: Int) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (status.isRooted)
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.errorContainer
            )
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = if (status.isRooted) "运行正常 (${status.framework.displayName})" else "未检测到 Root 权限",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Text("后端版本：${status.frameworkVersion}")
                Text("已授权应用：$grantedCount 个  |  已安装模块：$moduleCount 个")
            }
        }
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("设备环境", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("内核版本：${status.kernelVersion}")
                Text("SELinux 状态：${status.selinuxMode}")
            }
        }
    }
}

@Composable
fun SuperuserScreen(
    apps: List<InstalledAppItem>,
    framework: RootFramework,
    onUpdate: (InstalledAppItem, Boolean, Boolean) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = remember(apps, search) {
        if (search.isBlank()) apps
        else apps.filter {
            it.appName.contains(search, ignoreCase = true) ||
                it.packageName.contains(search, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("搜索应用名称或包名") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.uid }) { item ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.appName, fontWeight = FontWeight.SemiBold)
                                Text("${item.packageName} (UID ${item.uid})", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(
                                checked = item.granted,
                                onCheckedChange = { onUpdate(item, it, if (it) false else item.denyList) }
                            )
                        }
                        if (framework == RootFramework.MAGISK || framework == RootFramework.KERNEL_SU) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("DenyList / 隐藏 Root", style = MaterialTheme.typography.bodySmall)
                                Checkbox(
                                    checked = item.denyList,
                                    onCheckedChange = { onUpdate(item, if (it) false else item.granted, it) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModulesScreen(
    modules: List<RootModule>,
    onToggle: (RootModule, Boolean) -> Unit,
    onRemove: (RootModule, Boolean) -> Unit
) {
    if (modules.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("未检测到已安装模块 (/data/adb/modules)")
        }
        return
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(modules, key = { it.id }) { mod ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${mod.name} (${mod.version})", fontWeight = FontWeight.Bold)
                            Text("作者：${mod.author}", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = mod.enabled, onCheckedChange = { onToggle(mod, it) })
                    }
                    if (mod.description.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(mod.description, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { onRemove(mod, !mod.pendingRemove) }) {
                        Text(if (mod.pendingRemove) "取消卸载 (重启生效)" else "卸载模块")
                    }
                }
            }
        }
    }
}

@Composable
fun LogsScreen(logs: List<SuLogEntry>, onClear: () -> Unit) {
    val fmt = remember { SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()) }
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("共 ${logs.size} 条请求记录", style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onClear) { Text("清空日志") }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(logs, key = { it.id }) { entry ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(entry.packageName, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (entry.allowed) "已允许" else "已拒绝",
                                color = if (entry.allowed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                        Text(
                            text = entry.command,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "UID ${entry.uid} · ${fmt.format(Date(entry.timestamp))}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }
}
