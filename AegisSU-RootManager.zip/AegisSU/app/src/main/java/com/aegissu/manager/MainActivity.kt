package com.aegissu.manager

import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.Canvas
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aegissu.manager.core.*
import com.aegissu.manager.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class InstalledAppItem(
    val uid: Int,
    val packageName: String,
    val appName: String,
    val isSystem: Boolean,
    val granted: Boolean,
    val denyList: Boolean
)

data class KsuNavItem(
    val label: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        setContent {
            AegisSuRootApp()
        }
    }
}

fun buildThemeScheme(darkTheme: Boolean): ColorScheme {
    val ksuBlue = Color(0xFF2563EB)
    return if (darkTheme) {
        darkColorScheme(
            primary = Color(0xFF3B82F6),
            onPrimary = Color.White,
            primaryContainer = Color(0xFF1E293B),
            onPrimaryContainer = Color(0xFF93C5FD),
            background = Color(0xFF000000),
            surface = Color(0xFF161618),
            surfaceVariant = Color(0xFF242428),
            onSurface = Color(0xFFF3F4F6),
            onSurfaceVariant = Color(0xFF9CA3AF)
        )
    } else {
        lightColorScheme(
            primary = ksuBlue,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFEFF6FF),
            onPrimaryContainer = ksuBlue,
            background = Color(0xFFF3F4F6),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE5E7EB),
            onSurface = Color(0xFF111827),
            onSurfaceVariant = Color(0xFF6B7280)
        )
    }
}

fun decodeSampledBitmap(path: String, reqWidth: Int = 1080, reqHeight: Int = 2400): ImageBitmap? {
    return try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        var inSampleSize = 1
        val (height, width) = opts.outHeight to opts.outWidth
        if (height > reqHeight || width > reqWidth) {
            val halfH = height / 2
            val halfW = width / 2
            while (halfH / inSampleSize >= reqHeight && halfW / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        val decodeOpts = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        BitmapFactory.decodeFile(path, decodeOpts)?.asImageBitmap()
    } catch (_: Exception) {
        null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AegisSuRootApp() {
    val context = LocalContext.current
    val db = remember { PolicyDbHelper(context) }
    val prefStore = remember { AppPreferences(context) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var uiSettings by remember { mutableStateOf(prefStore.load()) }
    val systemDark = isSystemInDarkTheme()
    val useDark = when (uiSettings.themeMode) {
        1 -> false
        2 -> true
        else -> systemDark
    }

    val colorScheme = if (uiSettings.useMonet && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (useDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        remember(useDark) { buildThemeScheme(useDark) }
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var showBootPatchSheet by remember { mutableStateOf(false) }

    var status by remember {
        mutableStateOf(
            SystemStatus(RootFramework.NONE, "-", "-", "-", "-", "-", "-", "-", false)
        )
    }
    var apps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var modules by remember { mutableStateOf<List<RootModule>>(emptyList()) }
    var logs by remember { mutableStateOf<List<SuLogEntry>>(emptyList()) }
    var showRebootDialog by remember { mutableStateOf(false) }
    var customBgBitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(uiSettings.bgImagePath) {
        val p = uiSettings.bgImagePath
        customBgBitmap = if (!p.isNullOrBlank() && File(p).exists()) {
            withContext(Dispatchers.IO) { decodeSampledBitmap(p) }
        } else null
    }

    fun updateSettings(newSettings: UiSettings) {
        uiSettings = newSettings
        prefStore.save(newSettings)
    }

    fun refreshAll() {
        scope.launch {
            val statusDeferred = async(Dispatchers.IO) { RootBackend.detectSystemStatus() }
            val policiesDeferred = async(Dispatchers.IO) { db.getAllPolicies() }
            val modulesDeferred = async(Dispatchers.IO) { RootBackend.listModules() }
            val logsDeferred = async(Dispatchers.IO) { db.getLogs() }
            val appsDeferred = async(Dispatchers.IO) {
                val pm = context.packageManager
                val policies = policiesDeferred.await()
                pm.getInstalledApplications(0)
                    .map { info ->
                        val p = policies[info.uid]
                        InstalledAppItem(
                            uid = info.uid,
                            packageName = info.packageName,
                            appName = pm.getApplicationLabel(info).toString(),
                            isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                            granted = p?.granted ?: false,
                            denyList = p?.denyList ?: false
                        )
                    }
                    .sortedWith(compareByDescending<InstalledAppItem> { it.granted }.thenBy { it.appName })
            }

            status = statusDeferred.await()
            modules = modulesDeferred.await()
            logs = logsDeferred.await()
            apps = appsDeferred.await()
        }
    }

    val moduleZipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val msg = withContext(Dispatchers.IO) {
                    val tmpFile = File(context.cacheDir, "pending_module.zip")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        tmpFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    val res = RootBackend.installModuleZip(status.framework, tmpFile.absolutePath)
                    if (res.exitCode == 0) "模块刷入成功，重启后生效" else "刷入失败：${res.stderr}"
                }
                snackbarHostState.showSnackbar(msg)
                refreshAll()
            }
        }
    }

    LaunchedEffect(Unit) { refreshAll() }

    val grantedCount = remember(apps) { apps.count { it.granted } }
    val baseDensity = LocalDensity.current
    val scaledDensity = remember(baseDensity, uiSettings.uiScale) {
        Density(baseDensity.density * uiSettings.uiScale, baseDensity.fontScale)
    }

    CompositionLocalProvider(LocalDensity provides scaledDensity) {
        MaterialTheme(colorScheme = colorScheme) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Wallpaper Layer with optional real GPU Blur
                if (customBgBitmap != null) {
                    val blurMod = if (uiSettings.enableBlur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        Modifier.fillMaxSize().blur(18.dp)
                    } else {
                        Modifier.fillMaxSize()
                    }
                    Image(
                        bitmap = customBgBitmap!!,
                        contentDescription = "Wallpaper",
                        contentScale = ContentScale.Crop,
                        modifier = blurMod
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                (if (useDark) Color.Black else Color.White)
                                    .copy(alpha = uiSettings.bgDimAlpha)
                            )
                    )
                }

                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    snackbarHost = {
                        SnackbarHost(
                            hostState = snackbarHostState,
                            modifier = Modifier.padding(bottom = 100.dp)
                        )
                    },
                    topBar = {
                        val topBg = if (uiSettings.enableBlur) {
                            MaterialTheme.colorScheme.background.copy(alpha = 0.78f)
                        } else {
                            Color.Transparent
                        }
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(containerColor = topBg),
                            title = {
                                Text(
                                    text = when (selectedTab) {
                                        0 -> "AegisSU"
                                        1 -> "超级用户"
                                        2 -> "模块"
                                        else -> "主题与设置"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 21.sp
                                )
                            },
                            actions = {
                                IconButton(onClick = { refreshAll() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "刷新")
                                }
                                IconButton(onClick = { showRebootDialog = true }) {
                                    Icon(Icons.Default.PowerSettingsNew, contentDescription = "电源")
                                }
                            }
                        )
                    },
                    floatingActionButton = {
                        if (selectedTab == 2) {
                            FloatingActionButton(
                                onClick = { moduleZipPicker.launch(arrayOf("application/zip", "application/octet-stream")) },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = Color.White,
                                shape = CircleShape,
                                modifier = Modifier.padding(bottom = if (uiSettings.floatingBar) 92.dp else 72.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "安装模块")
                            }
                        }
                    }
                ) { innerPadding ->
                    val contentLayer = rememberGraphicsLayer()
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = innerPadding.calculateTopPadding())
                    ) {
                        val cardAlpha = if (customBgBitmap != null) 0.86f else 1f
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .drawWithContent {
                                    contentLayer.record {
                                        this@drawWithContent.drawContent()
                                    }
                                    drawLayer(contentLayer)
                                }
                        ) {

                        when (selectedTab) {
                            0 -> HomeScreen(
                                status = status,
                                grantedCount = grantedCount,
                                moduleCount = modules.size,
                                cardAlpha = cardAlpha,
                                onOpenPatcher = { showBootPatchSheet = true },
                                onDeployDaemon = {
                                    scope.launch {
                                        val soPath = "${context.applicationInfo.nativeLibraryDir}/libaegissu.so"
                                        val res = withContext(Dispatchers.IO) { RootBackend.deployNativeDaemon(soPath) }
                                        val msg = if (res.exitCode == 0) "原生守护进程已启动" else "部署失败：当前设备未激活 Root"
                                        snackbarHostState.showSnackbar(msg)
                                        refreshAll()
                                    }
                                }
                            )
                            1 -> SuperuserScreen(
                                apps = apps,
                                cardAlpha = cardAlpha,
                                onUpdate = { item, granted, denyList ->
                                    scope.launch(Dispatchers.IO) {
                                        db.upsertPolicy(item.uid, item.packageName, item.appName, granted, denyList)
                                        RootBackend.writePolicyForDaemon(item.uid, granted)
                                        RootBackend.setDenyList(status.framework, item.packageName, denyList)
                                        refreshAll()
                                    }
                                }
                            )
                            2 -> ModulesScreen(
                                modules = modules,
                                cardAlpha = cardAlpha,
                                onToggle = { mod, enable ->
                                    scope.launch(Dispatchers.IO) {
                                        RootBackend.toggleModule(mod.id, enable)
                                        refreshAll()
                                    }
                                },
                                onRemove = { mod, remove ->
                                    scope.launch(Dispatchers.IO) {
                                        RootBackend.toggleRemoveModule(mod.id, remove)
                                        refreshAll()
                                    }
                                }
                            )
                            3 -> ThemeAndSettingsScreen(
                                settings = uiSettings,
                                darkTheme = useDark,
                                logs = logs,
                                cardAlpha = cardAlpha,
                                onUpdateSettings = { updateSettings(it) },
                                onClearLogs = {
                                    scope.launch(Dispatchers.IO) {
                                        db.clearLogs()
                                        refreshAll()
                                    }
                                },
                                onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                            )
                        }

                        }

                        // Apple-style Liquid Glass Bottom Navigation Bar with Real Backdrop Refraction & Drag
                        AppleLiquidBottomBar(
                            selectedIndex = selectedTab,
                            grantedCount = if (uiSettings.showNavBadges) grantedCount else 0,
                            moduleCount = if (uiSettings.showNavBadges) modules.size else 0,
                            darkTheme = useDark,
                            floating = uiSettings.floatingBar,
                            liquidGlass = uiSettings.liquidGlass,
                            enableBlur = uiSettings.enableBlur,
                            contentLayer = contentLayer,
                            onSelect = { selectedTab = it },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }
            }

            if (showBootPatchSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showBootPatchSheet = false },
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    BootPatcherSheetContent(
                        status = status,
                        onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                    )
                }
            }

            if (showRebootDialog) {
                AlertDialog(
                    onDismissRequest = { showRebootDialog = false },
                    title = { Text("电源菜单") },
                    text = { Text("选择要执行的重启方式") },
                    confirmButton = {
                        Button(onClick = {
                            showRebootDialog = false
                            scope.launch(Dispatchers.IO) { RootBackend.reboot() }
                        }) { Text("重启系统") }
                    },
                    dismissButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = {
                                showRebootDialog = false
                                scope.launch(Dispatchers.IO) { RootBackend.reboot("recovery") }
                            }) { Text("Recovery") }
                            FilledTonalButton(onClick = {
                                showRebootDialog = false
                                scope.launch(Dispatchers.IO) { RootBackend.reboot("bootloader") }
                            }) { Text("Fastboot") }
                        }
                    }
                )
            }
        }
    }
}

private const val LIQUID_GLASS_AGSL = "uniform shader composable; uniform float2 size; uniform float cornerRadius; float sdRoundedBox(float2 p, float2 b, float r) { float2 q = abs(p) - b + r; return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r; } half4 main(float2 fragCoord) { float2 center = size * 0.5; float2 p = fragCoord - center; float d = sdRoundedBox(p, center, cornerRadius); if (d > 0.0) { return composable.eval(fragCoord); } float edge = smoothstep(-32.0, 0.0, d); float2 dir = length(p) > 0.001 ? normalize(p) : float2(0.0); float2 ro = -dir * edge * 12.0; return half4(composable.eval(fragCoord + ro * 1.22).r, composable.eval(fragCoord + ro).g, composable.eval(fragCoord + ro * 0.78).b, composable.eval(fragCoord + ro).a); }"

@Composable
fun AppleLiquidBottomBar(
    selectedIndex: Int,
    grantedCount: Int,
    moduleCount: Int,
    darkTheme: Boolean,
    floating: Boolean,
    liquidGlass: Boolean,
    enableBlur: Boolean,
    contentLayer: GraphicsLayer,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        KsuNavItem("主页", Icons.Filled.Home),
        KsuNavItem("超级用户", Icons.Filled.Security, grantedCount),
        KsuNavItem("模块", Icons.Filled.Extension, moduleCount),
        KsuNavItem("设置", Icons.Filled.Settings)
    )

    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val currentSelected by rememberUpdatedState(selectedIndex)
    val currentOnSelect by rememberUpdatedState(onSelect)

    var barPosInRoot by remember { mutableStateOf(Offset.Zero) }
    var isDragging by remember { mutableStateOf(false) }
    var dragOffsetPx by remember { mutableFloatStateOf(0f) }
    var hoveredIndex by remember(selectedIndex) { mutableIntStateOf(selectedIndex) }

    val activeColor = MaterialTheme.colorScheme.primary
    val inactiveColor = if (darkTheme) Color(0xFFF3F4F6) else Color(0xFF111827)

    val outerShape = if (floating) RoundedCornerShape(34.dp) else RoundedCornerShape(0.dp)
    val pillShape = RoundedCornerShape(29.dp)

    val outerTint = if (darkTheme) {
        Color(0xFF1C1E24).copy(alpha = if (liquidGlass) 0.56f else 0.90f)
    } else {
        Color.White.copy(alpha = if (liquidGlass) 0.60f else 0.94f)
    }

    val rimBrush = if (liquidGlass) {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = if (darkTheme) 0.55f else 0.98f),
                Color.White.copy(alpha = if (darkTheme) 0.12f else 0.25f),
                activeColor.copy(alpha = if (darkTheme) 0.40f else 0.28f),
                Color.White.copy(alpha = if (darkTheme) 0.32f else 0.88f)
            )
        )
    } else {
        Brush.linearGradient(listOf(Color.Gray.copy(alpha = 0.16f), Color.Gray.copy(alpha = 0.16f)))
    }

    val containerMod = if (floating) {
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 22.dp, vertical = 14.dp)
            .fillMaxWidth()
            .height(66.dp)
            .onGloballyPositioned { barPosInRoot = it.positionInRoot() }
            .shadow(
                elevation = if (liquidGlass) 22.dp else 12.dp,
                shape = outerShape,
                ambientColor = Color.Black.copy(alpha = 0.22f),
                spotColor = Color.Black.copy(alpha = 0.22f)
            )
            .clip(outerShape)
            .border(1.dp, rimBrush, outerShape)
    } else {
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .height(62.dp)
            .onGloballyPositioned { barPosInRoot = it.positionInRoot() }
            .border(0.5.dp, Color.Gray.copy(alpha = 0.15f))
    }

    val agslShader = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try { RuntimeShader(LIQUID_GLASS_AGSL) } catch (_: Throwable) { null }
        } else null
    }

    BoxWithConstraints(modifier = containerMod) {
        val barWidthPx = with(density) { maxWidth.toPx() }
        val innerPadPx = with(density) { 5.dp.toPx() }
        val usableWidthPx = (barWidthPx - innerPadPx * 2f).coerceAtLeast(1f)
        val tabWidthPx = usableWidthPx / items.size
        val maxOffsetPx = (usableWidthPx - tabWidthPx).coerceAtLeast(0f)

        val targetOffsetPx = if (isDragging) dragOffsetPx else currentSelected * tabWidthPx
        val animatedOffsetPx by animateFloatAsState(
            targetValue = targetOffsetPx,
            animationSpec = if (isDragging) {
                spring(dampingRatio = 1.0f, stiffness = Spring.StiffnessHigh)
            } else {
                spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMediumLow)
            },
            label = "drag_pill_px"
        )

        val dropletScaleX by animateFloatAsState(
            targetValue = if (isDragging && liquidGlass) 1.15f else 1.0f,
            animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
            label = "droplet_sx"
        )
        val dropletScaleY by animateFloatAsState(
            targetValue = if (isDragging && liquidGlass) 1.08f else 1.0f,
            animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
            label = "droplet_sy"
        )

        if (enableBlur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Canvas(
                modifier = Modifier
                    .matchParentSize()
                    .blur(20.dp)
            ) {
                translate(left = -barPosInRoot.x, top = -barPosInRoot.y) {
                    drawLayer(contentLayer)
                }
            }
        }
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(outerTint)
        )

        // Unified single gesture handler: 100% reliable Tap AND Horizontal Drag
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(5.dp)
                .pointerInput(tabWidthPx, maxOffsetPx) {
                    val touchSlop = viewConfiguration.touchSlop
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val startX = down.position.x
                        var dragged = false
                        var lastHovered = (startX / tabWidthPx).toInt().coerceIn(0, items.lastIndex)

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) {
                                // Finger lifted
                                if (dragged) {
                                    isDragging = false
                                    if (lastHovered != currentSelected) {
                                        currentOnSelect(lastHovered)
                                    }
                                } else {
                                    val tapped = (change.position.x / tabWidthPx).toInt().coerceIn(0, items.lastIndex)
                                    if (tapped != currentSelected) {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        currentOnSelect(tapped)
                                    }
                                }
                                break
                            }

                            val dx = change.position.x - startX
                            if (!dragged && kotlin.math.abs(dx) > touchSlop) {
                                dragged = true
                                isDragging = true
                            }
                            if (dragged) {
                                change.consume()
                                dragOffsetPx = (change.position.x - tabWidthPx / 2f).coerceIn(0f, maxOffsetPx)
                                val hovered = ((dragOffsetPx + tabWidthPx / 2f) / tabWidthPx)
                                    .toInt()
                                    .coerceIn(0, items.lastIndex)
                                if (hovered != lastHovered) {
                                    lastHovered = hovered
                                    hoveredIndex = hovered
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                        }
                    }
                }
        ) {
            val tabWidthDp = with(density) { tabWidthPx.toDp() }
            val pillHeightPx = with(density) { 56.dp.toPx() }
            val pillCornerPx = with(density) { 29.dp.toPx() }

            Box(
                modifier = Modifier
                    .offset { IntOffset(animatedOffsetPx.roundToInt(), 0) }
                    .width(tabWidthDp)
                    .fillMaxHeight()
                    .graphicsLayer {
                        scaleX = dropletScaleX
                        scaleY = dropletScaleY
                        if (liquidGlass && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && agslShader != null && tabWidthPx > 2f && pillHeightPx > 2f) {
                            agslShader.setFloatUniform("size", tabWidthPx, pillHeightPx)
                            agslShader.setFloatUniform("cornerRadius", pillCornerPx)
                            renderEffect = AndroidRenderEffect
                                .createRuntimeShaderEffect(agslShader, "composable")
                                .asComposeRenderEffect()
                        }
                    }
                    .clip(pillShape)
            ) {
                if (liquidGlass && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        scale(scaleX = 1.14f, scaleY = 1.14f, pivot = center) {
                            translate(
                                left = -(barPosInRoot.x + innerPadPx + animatedOffsetPx),
                                top = -(barPosInRoot.y + innerPadPx)
                            ) {
                                drawLayer(contentLayer)
                            }
                        }
                    }
                }

                val pillFill = if (liquidGlass) {
                    if (darkTheme) {
                        Brush.verticalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.28f),
                                Color.White.copy(alpha = 0.08f),
                                activeColor.copy(alpha = 0.16f)
                            )
                        )
                    } else {
                        Brush.verticalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.72f),
                                Color(0xFFE5E7EB).copy(alpha = 0.40f),
                                activeColor.copy(alpha = 0.12f)
                            )
                        )
                    }
                } else {
                    val solid = if (darkTheme) Color.White.copy(alpha = 0.14f) else Color(0xFFE5E7EB)
                    Brush.verticalGradient(listOf(solid, solid))
                }

                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(pillFill)
                        .then(
                            if (liquidGlass) {
                                Modifier.border(
                                    width = 1.2.dp,
                                    brush = Brush.linearGradient(
                                        listOf(
                                            Color.White.copy(alpha = if (darkTheme) 0.70f else 1.0f),
                                            Color.Transparent,
                                            activeColor.copy(alpha = 0.35f),
                                            Color.White.copy(alpha = if (darkTheme) 0.45f else 0.85f)
                                        )
                                    ),
                                    shape = pillShape
                                )
                            } else Modifier
                        )
                )
            }

            val visualActive = if (isDragging) hoveredIndex else currentSelected
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEachIndexed { idx, item ->
                    val selected = idx == visualActive
                    val tint by animateColorAsState(
                        targetValue = if (selected) activeColor else inactiveColor,
                        label = "tab_tint"
                    )
                    val iconScale by animateFloatAsState(
                        targetValue = if (selected && liquidGlass) 1.12f else 1.0f,
                        animationSpec = spring(dampingRatio = 0.55f),
                        label = "icon_bounce"
                    )

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label,
                                tint = tint,
                                modifier = Modifier
                                    .padding(horizontal = 6.dp)
                                    .size(23.dp)
                                    .graphicsLayer {
                                        scaleX = iconScale
                                        scaleY = iconScale
                                    }
                            )
                            if (item.badgeCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .offset(x = 2.dp, y = (-3).dp)
                                        .defaultMinSize(minWidth = 17.dp, minHeight = 17.dp)
                                        .clip(CircleShape)
                                        .background(activeColor)
                                        .padding(horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (item.badgeCount > 99) "99+" else item.badgeCount.toString(),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 10.sp
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = item.label,
                            color = tint,
                            fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CleanCard(
    alpha: Float,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = containerColor.copy(alpha = alpha),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
    ) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun HomeScreen(
    status: SystemStatus,
    grantedCount: Int,
    moduleCount: Int,
    cardAlpha: Float,
    onOpenPatcher: () -> Unit,
    onDeployDaemon: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var memPair by remember { mutableStateOf(0L to 1L) }
    var cpuTemp by remember { mutableFloatStateOf(0f) }
    var batteryPct by remember { mutableIntStateOf(0) }
    var batteryTemp by remember { mutableFloatStateOf(0f) }
    var storageUsedPct by remember { mutableFloatStateOf(0f) }
    var storageText by remember { mutableStateOf("-") }
    var wirelessAdb by remember { mutableStateOf(false) }
    var localIp by remember { mutableStateOf("-") }
    var toolboxMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            memPair = RootBackend.getMemoryUsage()
            cpuTemp = RootBackend.getCpuTempCelsius()
            wirelessAdb = RootBackend.isWirelessAdbEnabled()
            localIp = RootBackend.getLocalIpAddress()

            val stat = StatFs(Environment.getDataDirectory().path)
            val totalGb = stat.totalBytes / (1024f * 1024f * 1024f)
            val availGb = stat.availableBytes / (1024f * 1024f * 1024f)
            val usedGb = (totalGb - availGb).coerceAtLeast(0f)
            storageUsedPct = if (totalGb > 0f) (usedGb / totalGb).coerceIn(0f, 1f) else 0f
            storageText = String.format(Locale.getDefault(), "%.1f / %.1f GB", usedGb, totalGb)

            val bIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (bIntent != null) {
                val lvl = bIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                val scale = bIntent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                batteryPct = (lvl * 100) / scale
                batteryTemp = bIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .padding(bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CleanCard(
            alpha = cardAlpha,
            containerColor = if (status.isRooted)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.surface
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (status.isRooted) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (status.isRooted) Icons.Default.VerifiedUser else Icons.Default.GppMaybe,
                        contentDescription = null,
                        tint = if (status.isRooted) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(25.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (status.isRooted) "工作中 · ${status.framework.displayName}" else "未安装 Root",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (status.isRooted)
                            "版本: ${status.frameworkVersion} · 槽位: ${status.slotSuffix}"
                        else
                            "点击下方按钮修补 boot.img 获取 Root 权限",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onOpenPatcher,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.BuildCircle, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("修补 Boot 镜像")
                }
                FilledTonalButton(
                    onClick = onDeployDaemon,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("部署守护")
                }
            }
        }

        // Hardware & Telemetry Dashboard
        CleanCard(alpha = cardAlpha) {
            Text("实时手机状态", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))

            val memUsed = memPair.first
            val memTotal = memPair.second.coerceAtLeast(1L)
            val memProgress = (memUsed.toFloat() / memTotal.toFloat()).coerceIn(0f, 1f)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("运行内存 (RAM)", style = MaterialTheme.typography.bodySmall)
                Text("$memUsed / $memTotal MB", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { memProgress },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp))
            )

            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("内部存储 (/data)", style = MaterialTheme.typography.bodySmall)
                Text(storageText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { storageUsedPct },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp))
            )

            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("电池电量", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$batteryPct% · ${batteryTemp}°C", fontWeight = FontWeight.Bold)
                    }
                }
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("CPU 温度", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(if (cpuTemp > 0f) String.format(Locale.getDefault(), "%.1f°C", cpuTemp) else "-", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Practical Root Toolbox
        CleanCard(alpha = cardAlpha) {
            Text("实用手机工具箱", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            val res = withContext(Dispatchers.IO) { RootBackend.trimCachesAndFstrim() }
                            memPair = withContext(Dispatchers.IO) { RootBackend.getMemoryUsage() }
                            toolboxMsg = if (res.exitCode == 0) "已释放内核缓存并执行 FSTRIM" else "需要 Root 权限"
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CleaningServices, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("清理内存缓存")
                }

                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            val nextPermissive = status.selinuxMode.equals("Enforcing", ignoreCase = true)
                            val res = withContext(Dispatchers.IO) { RootBackend.setSelinuxPermissive(nextPermissive) }
                            toolboxMsg = if (res.exitCode == 0) {
                                "已请求切换 SELinux 为 ${if (nextPermissive) "Permissive" else "Enforcing"}"
                            } else "切换失败（需要 Root）"
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Shield, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("切换 SELinux")
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("无线 ADB 调试 (端口 5555)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    Text(
                        text = if (wirelessAdb) "已开启: adb connect $localIp:5555" else "开启后可通过 Wi-Fi 无线调试",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = wirelessAdb,
                    onCheckedChange = { enable ->
                        scope.launch {
                            val res = withContext(Dispatchers.IO) { RootBackend.toggleWirelessAdb(enable) }
                            if (res.exitCode == 0) {
                                wirelessAdb = enable
                                toolboxMsg = if (enable) "无线 ADB 已开启 ($localIp:5555)" else "无线 ADB 已关闭"
                            } else {
                                toolboxMsg = "切换无线 ADB 失败（需 Root 权限）"
                            }
                        }
                    }
                )
            }

            toolboxMsg?.let { msg ->
                Spacer(Modifier.height(6.dp))
                Text(msg, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CleanCard(alpha = cardAlpha, modifier = Modifier.weight(1f)) {
                Text("已授权应用", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text("$grantedCount", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            CleanCard(alpha = cardAlpha, modifier = Modifier.weight(1f)) {
                Text("已加载模块", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text("$moduleCount", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }

        CleanCard(alpha = cardAlpha) {
            Text("设备信息", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            InfoRow("设备型号", status.deviceModel)
            InfoRow("Android 版本", status.androidVersion)
            InfoRow("内核版本", status.kernelVersion)
            InfoRow("架构", status.abi)
            InfoRow("当前槽位", status.slotSuffix)
            InfoRow("SELinux", status.selinuxMode)
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(12.dp))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun BootPatcherSheetContent(
    status: SystemStatus,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedBootFile by remember { mutableStateOf<File?>(null) }
    var bootHeader by remember { mutableStateOf<BootHeaderInfo?>(null) }
    var patchLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var patchedPath by remember { mutableStateOf<String?>(null) }
    var isBusy by remember { mutableStateOf(false) }

    val bootPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isBusy = true
                val copied = withContext(Dispatchers.IO) {
                    val f = File(context.cacheDir, "selected_boot.img")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        f.outputStream().use { out -> input.copyTo(out) }
                    }
                    f
                }
                val hdr = withContext(Dispatchers.IO) { BootImagePatcher.parseBootImage(copied) }
                selectedBootFile = copied
                bootHeader = hdr
                patchLogs = listOf(
                    "[*] 加载镜像: ${copied.length() / 1024} KB",
                    if (hdr.isValid) "[+] 头部有效: Boot Header v${hdr.headerVersion}, Page=${hdr.pageSize}"
                    else "[!] 无效镜像：未检测到 ANDROID! 魔数头"
                )
                isBusy = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("修补 Boot / Init_Boot 镜像", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "选择官方刷机包内的 boot.img 或 init_boot.img，注入原生 SU 守护二进制后输出到 Download 目录。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { bootPicker.launch(arrayOf("*/*")) },
                enabled = !isBusy,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("选择 boot.img")
            }
            if (status.isRooted) {
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            isBusy = true
                            val dest = File(context.cacheDir, "extracted_boot.img")
                            val res = withContext(Dispatchers.IO) { RootBackend.dumpActiveBootPartition(dest) }
                            if (res.exitCode == 0 && dest.exists()) {
                                selectedBootFile = dest
                                bootHeader = withContext(Dispatchers.IO) { BootImagePatcher.parseBootImage(dest) }
                                patchLogs = listOf("[+] 已提取当前槽位分区镜像 (${dest.length() / 1024} KB)")
                            } else {
                                onShowMessage(res.stderr.ifBlank { "提取失败" })
                            }
                            isBusy = false
                        }
                    },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("提取当前分区")
                }
            }
        }

        bootHeader?.let { hdr ->
            if (hdr.isValid) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val file = selectedBootFile ?: return@Button
                            scope.launch {
                                isBusy = true
                                val outcome = withContext(Dispatchers.IO) { BootImagePatcher.patchBootImage(context, file, hdr) }
                                patchLogs = outcome.logs
                                if (outcome.success) {
                                    patchedPath = outcome.outputPath
                                    onShowMessage("修补完成！已保存至 Download 目录")
                                }
                                isBusy = false
                            }
                        },
                        enabled = !isBusy,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isBusy) "修补中..." else "开始修补")
                    }
                    if (status.isRooted && patchedPath != null) {
                        FilledTonalButton(
                            onClick = {
                                val p = patchedPath ?: return@FilledTonalButton
                                scope.launch {
                                    isBusy = true
                                    val res = withContext(Dispatchers.IO) { RootBackend.flashBootPartition(File(p)) }
                                    onShowMessage(if (res.exitCode == 0) "刷入成功，重启生效" else "刷入失败: ${res.stderr}")
                                    isBusy = false
                                }
                            },
                            enabled = !isBusy,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("直接刷入")
                        }
                    }
                }
            }
        }

        if (patchLogs.isNotEmpty()) {
            Surface(
                color = Color(0xFF0F172A),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    patchLogs.forEach { line ->
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFE2E8F0))
                    }
                }
            }
        }
    }
}

@Composable
fun SuperuserScreen(
    apps: List<InstalledAppItem>,
    cardAlpha: Float,
    onUpdate: (InstalledAppItem, Boolean, Boolean) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var showSystemApps by remember { mutableStateOf(false) }

    val filtered = remember(apps, search, showSystemApps) {
        apps.filter { item ->
            (showSystemApps || !item.isSystem) &&
                (search.isBlank() ||
                    item.appName.contains(search, ignoreCase = true) ||
                    item.packageName.contains(search, ignoreCase = true))
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("搜索应用") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = showSystemApps,
                onClick = { showSystemApps = !showSystemApps },
                label = { Text("系统") }
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.uid }) { item ->
                CleanCard(alpha = cardAlpha) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.appName, fontWeight = FontWeight.SemiBold)
                            Text("${item.packageName} · UID ${item.uid}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = item.granted,
                            onCheckedChange = { onUpdate(item, it, if (it) false else item.denyList) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DenyList / 隐藏 Root", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Checkbox(
                            checked = item.denyList,
                            onCheckedChange = { onUpdate(item, if (it) false else item.granted, it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModulesScreen(
    modules: List<RootModule>,
    cardAlpha: Float,
    onToggle: (RootModule, Boolean) -> Unit,
    onRemove: (RootModule, Boolean) -> Unit
) {
    if (modules.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            CleanCard(alpha = cardAlpha) {
                Text("暂无已安装的模块", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("点击右下角 + 按钮选择本地模块 ZIP 安装", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(modules, key = { it.id }) { mod ->
            CleanCard(alpha = cardAlpha) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${mod.name} (${mod.version})", fontWeight = FontWeight.Bold)
                        Text("作者：${mod.author}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = mod.enabled, onCheckedChange = { onToggle(mod, it) })
                }
                if (mod.description.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(mod.description, style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { onRemove(mod, !mod.pendingRemove) }) {
                        Text(if (mod.pendingRemove) "取消卸载" else "卸载")
                    }
                }
            }
        }
    }
}

@Composable
fun ThemePreviewPhoneCard(settings: UiSettings, darkTheme: Boolean) {
    val bg = if (darkTheme) Color(0xFF141416) else Color(0xFFF9FAFB)
    val frame = if (darkTheme) Color(0xFF2E2E32) else Color(0xFFE5E7EB)
    val accent = MaterialTheme.colorScheme.primary
    val inactive = if (darkTheme) Color(0xFFE5E7EB) else Color(0xFF111827)

    Box(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .width(128.dp)
                .height(148.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(bg)
                .border(3.dp, frame, RoundedCornerShape(22.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth().weight(1f),
                shape = RoundedCornerShape(12.dp),
                color = if (darkTheme) Color(0xFF1F2024) else Color.White
            ) {}
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
                    .clip(RoundedCornerShape(if (settings.floatingBar) 13.dp else 4.dp))
                    .background(if (darkTheme) Color(0xFF27272A) else Color.White)
                    .border(0.6.dp, Color.Gray.copy(alpha = 0.25f), RoundedCornerShape(if (settings.floatingBar) 13.dp else 4.dp))
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(4) { idx ->
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (idx == 0) accent else inactive)
                    )
                }
            }
        }
    }
}

@Composable
fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
fun ThemeAndSettingsScreen(
    settings: UiSettings,
    darkTheme: Boolean,
    logs: List<SuLogEntry>,
    cardAlpha: Float,
    onUpdateSettings: (UiSettings) -> Unit,
    onClearLogs: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fmt = remember { SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()) }

    val wallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val savedFile = withContext(Dispatchers.IO) {
                    val dest = File(context.filesDir, "custom_wallpaper_${System.currentTimeMillis()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        dest.outputStream().use { out -> input.copyTo(out) }
                    }
                    dest
                }
                if (savedFile.exists() && savedFile.length() > 0) {
                    onUpdateSettings(settings.copy(bgImagePath = savedFile.absolutePath))
                    onShowMessage("自定义背景已应用")
                }
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ThemePreviewPhoneCard(settings, darkTheme)
        }

        // 3-segment theme switcher matching KSU screenshot
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(0 to "跟随系统", 1 to "浅色", 2 to "深色").forEach { (idx, label) ->
                    val selected = settings.themeMode == idx
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onUpdateSettings(settings.copy(themeMode = idx)) },
                        color = if (selected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(14.dp),
                        tonalElevation = if (selected) 2.dp else 0.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = label,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            CleanCard(alpha = cardAlpha) {
                SettingSwitchRow(
                    icon = Icons.Default.Palette,
                    title = "启用 Monet 颜色",
                    subtitle = "跟随系统壁纸动态取色 (Android 12+)",
                    checked = settings.useMonet,
                    onCheckedChange = { onUpdateSettings(settings.copy(useMonet = it)) }
                )
            }
        }

        item {
            CleanCard(alpha = cardAlpha) {
                SettingSwitchRow(
                    icon = Icons.Default.BlurOn,
                    title = "模糊",
                    subtitle = "启用顶栏和底栏的模糊效果",
                    checked = settings.enableBlur,
                    onCheckedChange = { onUpdateSettings(settings.copy(enableBlur = it)) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                SettingSwitchRow(
                    icon = Icons.Default.Dock,
                    title = "悬浮底栏",
                    subtitle = "使用 Apple 风格的悬浮底栏",
                    checked = settings.floatingBar,
                    onCheckedChange = { onUpdateSettings(settings.copy(floatingBar = it)) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                SettingSwitchRow(
                    icon = Icons.Default.WaterDrop,
                    title = "液态玻璃",
                    subtitle = "启用悬浮底栏的液态玻璃效果",
                    checked = settings.liquidGlass,
                    onCheckedChange = { onUpdateSettings(settings.copy(liquidGlass = it)) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                SettingSwitchRow(
                    icon = Icons.Default.Pin,
                    title = "导航栏角标",
                    subtitle = "在导航栏显示已授权应用和已启用模块数量",
                    checked = settings.showNavBadges,
                    onCheckedChange = { onUpdateSettings(settings.copy(showNavBadges = it)) }
                )
            }
        }

        item {
            CleanCard(alpha = cardAlpha) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("界面缩放", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                        Text("调整全局显示比例", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${(settings.uiScale * 100).toInt()}%", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = settings.uiScale,
                    onValueChange = { onUpdateSettings(settings.copy(uiScale = it)) },
                    valueRange = 0.80f..1.15f
                )

                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { wallpaperPicker.launch(arrayOf("image/*")) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Wallpaper, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("自定义背景图片")
                    }
                    if (!settings.bgImagePath.isNullOrBlank()) {
                        OutlinedButton(
                            onClick = {
                                onUpdateSettings(settings.copy(bgImagePath = null))
                                onShowMessage("已恢复默认背景")
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("清除") }
                    }
                }
                if (!settings.bgImagePath.isNullOrBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text("背景遮罩浓度: ${(settings.bgDimAlpha * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = settings.bgDimAlpha,
                        onValueChange = { onUpdateSettings(settings.copy(bgDimAlpha = it)) },
                        valueRange = 0.05f..0.85f
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SU 审计日志 (${logs.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                if (logs.isNotEmpty()) TextButton(onClick = onClearLogs) { Text("清空") }
            }
        }

        if (logs.isEmpty()) {
            item {
                CleanCard(alpha = cardAlpha) {
                    Text("暂无提权记录", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(logs, key = { it.id }) { entry ->
                CleanCard(alpha = cardAlpha) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(entry.packageName, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (entry.allowed) "允许" else "拒绝",
                            color = if (entry.allowed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    Text(entry.command, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                    Text("UID ${entry.uid} · ${fmt.format(Date(entry.timestamp))}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
