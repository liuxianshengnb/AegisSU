# AegisSU v2.0 — Android Root 管理器源码工程

全新升级版 **AegisSU v2.0**：
1. **KernelSU 风格底部液态胶囊导航栏 (`LiquidBottomNavBar`)**：带高阻尼弹簧 (`Spring`) 滑动胶囊指示器、半透明磨砂边框与图标弹性缩放动画。
2. **沉浸式透明系统导航栏与状态栏**：基于 `enableEdgeToEdge` 全屏延展，底部悬浮导航栏与手势小白条自然融合。
3. **真实 Boot / Init_Boot 镜像修补器 (`BootImagePatcher.kt`)**：
   - 真实二进制解析 Android Boot Image Header (`ANDROID!` 魔数、Header v0~v4、Kernel/Ramdisk 尺寸、PageSize、Cmdline 与 SHA-256 校验)。
   - 支持一键修补本地 `boot.img` / `init_boot.img`：自动优先调用 `/data/adb/ksud`、`magiskboot`，并在未 Root 手机上内置纯原生 **newc CPIO Ramdisk 注入引擎**，将 APK 内置编译的 `libaegissu.so` (04755 SUID 守护进程) 注入镜像并输出到系统 `Download` 目录。
   - 若设备已有 Root 权限，还支持直接提取当前活动槽位 (`boot_a`/`boot_b`) 分区镜像以及直接刷写。
4. **个性化设置板块与自定义壁纸 (`SettingsAndLogsScreen`)**：支持从手机相册选择任意图片设为全局背景、实时调节背景暗角遮罩浓度与卡片毛玻璃不透明度、切换浅色/深色模式及 4 套强调色方案。
