# AegisSU — Android Root 管理器源码工程

这是一个基于 **Kotlin + Jetpack Compose + Material 3** 与 **C 原生 `su` 守护进程** 构建的 Android Root 管理器完整源码工程，支持 **KernelSU / Magisk** 后端适配与独立 `su` 权限调度。

## 手机端通过 GitHub 云端自动打包 APK 步骤
1. 解压 `AegisSU-RootManager.zip`，得到 `AegisSU` 文件夹（注意里面包含隐藏目录 `.github`）。
2. 在手机浏览器（如 Chrome/Edge）登录 GitHub，新建一个仓库（例如 `AegisSU`）。
3. 在新建仓库页面点击 **uploading an existing file**，将 `AegisSU` 里的所有文件和文件夹（含 `.github`）上传并 Commit。
4. 打开手机上的 **GitHub App**，进入该仓库的 **Actions** 标签页，等待 `Build AegisSU APK` 运行完成（约 3~5 分钟）。
5. 构建变绿后点进去，在底部的 **Artifacts** 中下载 `AegisSU-debug-apk`，解压即可安装 `app-debug.apk`。

## 核心功能
1. **系统概览 (Home)**：自动检测当前 Root 后端（KernelSU / Magisk / AegisSU Daemon）、内核版本、SELinux 状态与设备信息，提供快捷重启菜单。
2. **超级用户授权与 DenyList (Superuser)**：基于内核 `SO_PEERCRED` 鉴权，支持永久允许/仅本次允许/拒绝，以及 DenyList / Umount 应用隐藏。
3. **实时授权弹窗 (`SuPromptActivity`)**：未知应用请求 `su` 时弹出带 15 秒倒计时的授权界面。
4. **模块管理 (Modules)**：读取 `/data/adb/modules`，支持启用/禁用、卸载标记以及选择本地 `.zip` 模块包刷入。
5. **审计日志 (Logs)**：记录每次 `su` 请求的时间、包名、UID、命令与结果。
