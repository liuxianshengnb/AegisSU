#!/system/bin/sh
MODDIR=${0%/*}
AEGIS_BIN="/data/adb/aegissu/su"

if [ -x "$AEGIS_BIN" ]; then
    chmod 04755 "$AEGIS_BIN"
    "$AEGIS_BIN" --daemon &
fi
