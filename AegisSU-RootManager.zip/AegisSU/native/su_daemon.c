#define _GNU_SOURCE
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>

#define SOCKET_PATH "/dev/socket/aegissu.sock"
#define POLICY_DB_DIR "/data/adb/aegissu/policy"
#define MAX_CMD_LEN 1024

typedef struct {
    uid_t uid;
    pid_t pid;
    char command[MAX_CMD_LEN];
} su_request_t;

typedef struct {
    int allowed;
} su_response_t;

static int check_cached_policy(uid_t uid) {
    char path[256];
    snprintf(path, sizeof(path), "%s/%u", POLICY_DB_DIR, uid);
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    int val = 0;
    if (fscanf(fp, "%d", &val) != 1) val = 0;
    fclose(fp);
    return val;
}

static int prompt_user_via_am(uid_t uid, const char *command) {
    char cmd[1536];
    snprintf(
        cmd, sizeof(cmd),
        "am start -n com.aegissu.manager/.SuPromptActivity "
        "--ei uid %u --es command '%s' >/dev/null 2>&1",
        uid, command
    );
    return system(cmd);
}

static void handle_client(int client_fd) {
    struct ucred cred;
    socklen_t len = sizeof(cred);
    if (getsockopt(client_fd, SOL_SOCKET, SO_PEERCRED, &cred, &len) < 0) {
        close(client_fd);
        return;
    }

    su_request_t req;
    memset(&req, 0, sizeof(req));
    ssize_t n = read(client_fd, &req, sizeof(req));
    if (n <= 0) {
        close(client_fd);
        return;
    }

    uid_t real_uid = cred.uid;
    su_response_t resp = { .allowed = 0 };

    if (real_uid == 0 || real_uid == 2000) {
        resp.allowed = 1;
    } else {
        int cached = check_cached_policy(real_uid);
        if (cached == 1) {
            resp.allowed = 1;
        } else if (cached == 0) {
            resp.allowed = 0;
        } else {
            prompt_user_via_am(real_uid, req.command);
            for (int i = 0; i < 30; i++) {
                usleep(500000);
                cached = check_cached_policy(real_uid);
                if (cached >= 0) {
                    resp.allowed = cached;
                    break;
                }
            }
        }
    }

    write(client_fd, &resp, sizeof(resp));
    close(client_fd);
}

static int run_daemon(void) {
    unlink(SOCKET_PATH);
    int server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket");
        return 1;
    }

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path) - 1);

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_fd);
        return 1;
    }

    chmod(SOCKET_PATH, 0666);
    if (listen(server_fd, 16) < 0) {
        perror("listen");
        close(server_fd);
        return 1;
    }

    while (1) {
        int client_fd = accept(server_fd, NULL, NULL);
        if (client_fd >= 0) {
            if (fork() == 0) {
                close(server_fd);
                handle_client(client_fd);
                _exit(0);
            }
            close(client_fd);
        }
    }
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc >= 2 && strcmp(argv[1], "--daemon") == 0) {
        return run_daemon();
    }

    uid_t caller_uid = getuid();
    const char *exec_cmd = "/system/bin/sh";
    char joined_cmd[MAX_CMD_LEN] = "/system/bin/sh";

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-c") == 0 && i + 1 < argc) {
            snprintf(joined_cmd, sizeof(joined_cmd), "%s", argv[i + 1]);
            break;
        }
    }

    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) {
        fprintf(stderr, "su: daemon socket error\n");
        return 1;
    }

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path) - 1);

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        fprintf(stderr, "su: cannot connect to aegissu daemon\n");
        close(fd);
        return 1;
    }

    su_request_t req;
    req.uid = caller_uid;
    req.pid = getpid();
    snprintf(req.command, sizeof(req.command), "%s", joined_cmd);

    write(fd, &req, sizeof(req));
    su_response_t resp = { .allowed = 0 };
    read(fd, &resp, sizeof(resp));
    close(fd);

    if (!resp.allowed) {
        fprintf(stderr, "su: permission denied for uid %u\n", caller_uid);
        return 1;
    }

    if (setresgid(0, 0, 0) != 0 || setresuid(0, 0, 0) != 0) {
        perror("su: setresuid");
        return 1;
    }

    if (argc >= 3 && strcmp(argv[1], "-c") == 0) {
        char *sh_args[] = { (char *)exec_cmd, "-c", argv[2], NULL };
        execvp(exec_cmd, sh_args);
    } else {
        char *sh_args[] = { (char *)exec_cmd, NULL };
        execvp(exec_cmd, sh_args);
    }
    return 127;
}
